// Vercel Serverless Function - 剧本分析
import { GoogleGenAI } from '@google/genai';

const API_KEY = process.env.GEMINI_API_KEY;

export default async function handler(req, res) {
  // 设置 CORS
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  if (!API_KEY) {
    return res.status(503).json({ error: 'AI 服务未配置' });
  }

  try {
    const ai = new GoogleGenAI({ apiKey: API_KEY });
    const { script, charImages, sceneImages } = req.body;

    const prompt = `作为专业的抖音爆款短剧导演，请深度解析以下剧本。
要求：
1. 提取核心冲突、人物性格、场景氛围和情绪转折点。
2. 梳理出剧本中的关键台词，并明确指出"这句台词是谁说的"，以及"说完后观众/镜头的反应应该切给谁"。
3. 分析每个角色的外貌特征、服装风格、习惯性小动作。
4. 标注出剧本中的高潮点和情绪爆发点。

剧本内容：
${script}

请用中文详细分析：`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.0-flash',
      contents: prompt,
    });

    res.json({ result: response.text });
  } catch (error) {
    console.error('分析失败:', error);
    res.status(500).json({ error: error.message });
  }
}
