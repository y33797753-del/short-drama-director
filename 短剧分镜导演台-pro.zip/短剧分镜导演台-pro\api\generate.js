// Vercel Serverless Function - 生成分镜
import { GoogleGenAI } from '@google/genai';

const API_KEY = process.env.GEMINI_API_KEY;

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  if (!API_KEY) {
    return res.status(503).json({ error: 'AI 服务未配置' });
  }

  try {
    const ai = new GoogleGenAI({ apiKey: API_KEY });
    const { script, style, emotion, camera, motion, fx, customPrompt, totalDuration, charImages, sceneImages } = req.body;

    const styleMap = { 'xh': '金色玄幻', 'xx': '仙侠飘渺', 'md': '魔都暗黑', 'gw': '古武热血' };
    const emotionMap = { 'max': '极致爆发', 'hi': '高度外放', 'mid': '中度戏剧' };
    const cameraMap = { 'side': '侧面/斜侧优先', 'mix': '混合运镜', 'epic': '史诗大景', 'intimate': '亲密特写', 'fpv': '第一人称视角', 'tracking': '动态跟拍', 'orbit': '环绕镜头' };

    const prompt = `你是一位顶级的抖音述评短剧分镜大师。请严格按照以下剧本，将其按时间顺序拆解为连续的、不重复的多个分镜，并生成专供【即梦 Seedance 2.0】使用的超详细英文提示词（Prompt）。

【🔴 核心痛点与强制规则 - 违背视为失败】：
1. 🚫 彻底拒绝重复，必须推进剧情：你必须按剧本时间线顺延拆解！每一个分镜必须是剧情的下一步。绝对不能在多个分镜中重复相同的台词、动作或提示词！
2. ⏱️ 严格时长控制：所有分镜的时长相加，总时长【必须严格控制在 ${totalDuration}秒 之间】！
3. 🗣️ 台词与多重反应切镜：每个分镜必须明确写出"当前台词是谁说的"，说话时的【肢体辅助动作】是什么。并且，每个分镜必须增加对【至少3个不同配角】的反应镜头描述，并详细说明他们的微表情和情绪变化。
4. 🖼️ 严格遵循参考图与自定义名称
5. ✨ 精准且宏大的特效（VFX）：严格按照剧本，不是每个镜头都有特效！只有当剧本明确需要特效（如施法、爆发、打斗）时才添加。
6. 💡 创意运镜与构图：为每个生成的分镜，提供2-3个与当前选定运镜风格和构图手法相匹配的、更具创意的运镜和构图组合建议。
7. 🛑 附加全局提示词规则：用户提供的附加全局提示词必须且只能出现在【镜号标题处】，**绝对不要**将其放入最终生成的即梦 Seedance 2.0 英文提示词代码块中！

【📋 剧本内容】：
${script}

【🎨 拍摄参数】：
- 画面风格：${styleMap[style] || style}
- 情绪张力：${emotionMap[emotion] || emotion}
- 运镜风格：${cameraMap[camera] || camera}
- 附加提示词：${customPrompt || '无'}

【📝 输出格式要求】：
每个分镜必须包含：
1. 镜号与时长
2. 对应原剧本内容
3. 台词与多重反应（主角+3个配角的详细反应）
4. 运镜、景别、构图、光色
5. 即梦 Seedance 2.0 英文提示词（放在代码块中）

请开始生成：
`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.0-flash',
      contents: prompt,
    });

    res.json({ result: response.text });
  } catch (error) {
    console.error('生成失败:', error);
    res.status(500).json({ error: error.message });
  }
}
