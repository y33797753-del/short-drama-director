/// <reference types="vite/client" />
import React, { useState, useRef, useEffect } from 'react';
import { 
  Clapperboard, Settings, Image as ImageIcon, FileText, 
  Sparkles, Download, Copy, RefreshCw, ChevronDown, 
  Play, Type, Maximize, Minus, Plus, Upload, CheckCircle2,
  Camera, Loader2, Wifi, WifiOff
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { cameraTemplates, generatePrompt, selectTemplates, analyzeEmotion, getRandomReaction } from './templates';

// 动态导入本地 AI 模块，避免初始化错误
let localAI: any = null;
const loadLocalAI = async () => {
  if (!localAI) {
    try {
      localAI = await import('./localAI');
    } catch (e) {
      console.error('加载本地 AI 模块失败:', e);
    }
  }
  return localAI;
};

interface ReferenceImage {
  id: string;
  name: string;
  data: string;
}

// 英文提示词代码块组件
const CodeBlock = ({node, inline, className, children, ...props}: any) => {
  const str = String(children).replace(/\n$/, '');
  const [copied, setCopied] = useState(false);
  
  const handleCopy = () => {
    navigator.clipboard.writeText(str);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return !inline ? (
    <div className="relative group mt-6 mb-8">
      <div className="absolute -top-3 left-4 bg-gradient-to-r from-indigo-600 to-purple-600 text-xs px-3 py-1 rounded-full text-white font-bold tracking-wider shadow-lg border border-indigo-500/30">
        🪄 即梦 SEEDANCE 2.0 专属提示词
      </div>
      <button
        onClick={handleCopy}
        className="absolute top-4 right-4 p-2 bg-neutral-800 hover:bg-neutral-700 rounded-lg text-neutral-400 hover:text-white transition-all shadow-md z-10"
        title="一键复制提示词"
      >
        {copied ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
      </button>
      <pre className="bg-neutral-950 border border-indigo-500/20 rounded-xl p-5 pt-8 overflow-x-auto shadow-inner">
        <code className="text-indigo-200 font-mono text-sm leading-relaxed" {...props}>
          {children}
        </code>
      </pre>
    </div>
  ) : (
    <code className="bg-neutral-800 text-amber-200 px-1.5 py-0.5 rounded text-sm font-mono" {...props}>
      {children}
    </code>
  );
};

// 复制按钮组件
const CopyButton = ({ text, label = '复制' }: { text: string; label?: string }) => {
  const [copied, setCopied] = useState(false);
  
  const handleCopy = () => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <button
      onClick={handleCopy}
      className="flex items-center gap-1 px-2 py-1 bg-neutral-800 hover:bg-neutral-700 rounded text-xs text-neutral-400 hover:text-white transition-all"
      title={label}
    >
      {copied ? <CheckCircle2 className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
      {copied ? '已复制' : label}
    </button>
  );
};

export default function App() {
  const [showApiKeyInput, setShowApiKeyInput] = useState(false);
  const [serverStatus, setServerStatus] = useState<'checking' | 'ok' | 'error'>('checking');
  const [offlineMode, setOfflineMode] = useState(false); // 离线模式开关
  const [localAIMode, setLocalAIMode] = useState(false); // 本地 AI 模式
  const [localAIStatus, setLocalAIStatus] = useState<'not_loaded' | 'loading' | 'loaded' | 'error'>('not_loaded');
  const [localAIProgress, setLocalAIProgress] = useState(''); // 加载进度信息
  
  // 检查服务器状态
  useEffect(() => {
    if (offlineMode || localAIMode) return; // 离线或本地 AI 模式不检查服务器
    fetch('/api/health')
      .then(res => res.json())
      .then(data => {
        setServerStatus(data.aiAvailable ? 'ok' : 'error');
      })
      .catch(() => {
        setServerStatus('error');
      });
  }, [offlineMode, localAIMode]);

  // 加载本地 AI 模型
  useEffect(() => {
    if (localAIMode && localAIStatus === 'not_loaded') {
      setLocalAIStatus('loading');
      setLocalAIProgress('准备下载...');
      loadLocalAI().then(module => {
        if (module && module.initLocalAI) {
          module.initLocalAI((msg: string) => {
            setLocalAIProgress(msg);
          }).then((success: boolean) => {
            setLocalAIStatus(success ? 'loaded' : 'error');
            if (!success && module.getLoadError) {
              setLocalAIProgress('加载失败: ' + module.getLoadError());
            }
          });
        } else {
          setLocalAIStatus('error');
          setLocalAIProgress('模块加载失败');
        }
      });
    }
  }, [localAIMode, localAIStatus]);

  // State for settings
  const [style, setStyle] = useState('xh');
  const [emotion, setEmotion] = useState('max');
  const [camera, setCamera] = useState('side');
  const [pace, setPace] = useState('flow');
  const [motion, setMotion] = useState('ultra');
  const [fx, setFx] = useState('rich');
  const [duration, setDuration] = useState('0');
  const [totalDuration, setTotalDuration] = useState('180-210');
  const [chapterDuration, setChapterDuration] = useState('3');
  const [markers, setMarkers] = useState('on');

  // State for inputs
  const [script, setScript] = useState('');
  const [fullScript, setFullScript] = useState('');
  const [charImages, setCharImages] = useState<ReferenceImage[]>([]);
  const [sceneImages, setSceneImages] = useState<ReferenceImage[]>([]);
  const [customPromptAdditions, setCustomPromptAdditions] = useState('');

  // State for UI
  const [fontSize, setFontSize] = useState(14);
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isAnalyzingCharacters, setIsAnalyzingCharacters] = useState(false);
  const [characterAnalysis, setCharacterAnalysis] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [analysisResult, setAnalysisResult] = useState('');
  const [generatedPrompts, setGeneratedPrompts] = useState('');
  const [error, setError] = useState('');

  const handleError = (err: any, prefix: string) => {
    if (err.message?.includes('429') || err.message?.includes('RESOURCE_EXHAUSTED')) {
      setError(`${prefix}: 您的 API 请求过于频繁或已超出免费额度限制 (429 RESOURCE_EXHAUSTED)。请稍后再试。`);
    } else {
      setError(`${prefix}: ${err.message}`);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>, setter: React.Dispatch<React.SetStateAction<ReferenceImage[]>>, prefix: string) => {
    const files = e.target.files;
    if (!files) return;
    
    Array.from(files as Iterable<File>).forEach(file => {
      const reader = new FileReader();
      reader.onload = (e) => {
        if (e.target?.result) {
          setter(prev => [...prev, {
            id: Math.random().toString(36).substring(7),
            name: `${prefix} ${prev.length + 1}`,
            data: e.target!.result as string
          }]);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const analyzeScript = async () => {
    if (!script.trim()) {
      setError('请先输入剧本内容');
      return;
    }
    if (serverStatus !== 'ok') {
      setError('AI 服务未配置，请联系管理员');
      return;
    }
    setError('');
    setIsAnalyzing(true);
    try {
      const response = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ script, charImages, sceneImages })
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || '解析失败');
      }
      const data = await response.json();
      setAnalysisResult(data.result || '解析完成，但未返回内容。');
    } catch (err: any) {
      handleError(err, '解析失败');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const [isAnalyzingCamera, setIsAnalyzingCamera] = useState(false);

  const analyzeCameraStyle = async () => {
    if (!script.trim()) {
      setError('请先输入当前分镜剧本内容以分析运镜');
      return;
    }
    if (serverStatus !== 'ok') {
      setError('AI 服务未配置，请联系管理员');
      return;
    }
    setError('');
    setIsAnalyzingCamera(true);
    try {
      const response = await fetch('/api/analyze-camera', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ script })
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || '运镜分析失败');
      }
      const data = await response.json();
      const recommendedCamera = data.result || 'side';
      const validCameras = ['side', 'mix', 'epic', 'intimate', 'fpv', 'tracking', 'orbit'];
      if (validCameras.includes(recommendedCamera)) {
        setCamera(recommendedCamera);
        if (recommendedCamera === 'fpv' || recommendedCamera === 'tracking') {
          setPace('flow');
          setMotion('ultra');
        } else if (recommendedCamera === 'orbit') {
          setPace('epic');
          setMotion('high');
        } else if (recommendedCamera === 'intimate') {
          setPace('cut');
          setMotion('mid');
        }
      }
    } catch (err: any) {
      handleError(err, '运镜分析失败');
    } finally {
      setIsAnalyzingCamera(false);
    }
  };

  const analyzeFullScript = async () => {
    if (!fullScript.trim()) {
      setError('请先输入完整剧本内容');
      return;
    }
    if (serverStatus !== 'ok') {
      setError('AI 服务未配置，请联系管理员');
      return;
    }
    setError('');
    setIsAnalyzingCharacters(true);
    try {
      const response = await fetch('/api/analyze-characters', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fullScript })
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || '角色解析失败');
      }
      const data = await response.json();
      setCharacterAnalysis(data.result || '解析完成，但未返回内容。');
    } catch (err: any) {
      handleError(err, '角色解析失败');
    } finally {
      setIsAnalyzingCharacters(false);
    }
  };

  // 本地 AI 模式生成分镜
  const generateLocalAIPrompts = async () => {
    if (!script.trim()) {
      setError('请先输入剧本内容');
      return;
    }
    setError('');
    setIsGenerating(true);
    setGeneratedPrompts('');

    try {
      const module = await loadLocalAI();
      if (!module || !module.generateShotsWithLocalAI) {
        throw new Error('本地 AI 模块未加载');
      }

      await module.generateShotsWithLocalAI(
        script,
        style,
        emotion,
        camera,
        motion,
        fx,
        customPromptAdditions,
        (text: string) => {
          setGeneratedPrompts(prev => prev + text);
        }
      );
    } catch (err: any) {
      handleError(err, '本地 AI 生成失败');
    } finally {
      setIsGenerating(false);
    }
  };

  // 离线模式生成分镜 - 优化版，多样化反应镜头
  const generateOfflinePrompts = () => {
    if (!script.trim()) {
      setError('请先输入剧本内容');
      return;
    }
    setError('');
    setIsGenerating(true);
    setGeneratedPrompts('');

    // 解析剧本为句子
    const sentences = script.split(/[。！？\n]/).filter(s => s.trim());
    const templates = cameraTemplates[camera] || cameraTemplates.side;
    
    let result = '';
    const shotDuration = Math.floor(parseInt(totalDuration) / Math.max(sentences.length, 1));
    
    sentences.forEach((sentence, index) => {
      const template = templates[index % templates.length];
      const prompt = generatePrompt(style, emotion, camera, motion, fx, customPromptAdditions);
      
      // 分析当前句子的情绪
      const emotionType = analyzeEmotion(sentence);
      const mainReaction = getRandomReaction(emotionType);
      const reactionA = getRandomReaction(emotionType);
      const reactionB = getRandomReaction(emotionType);
      const reactionC = getRandomReaction(emotionType);
      
      // 生成多样化的反应描述
      const reactionText = sentence.includes('：') 
        ? `主角说"${sentence.split('：')[1].trim()}"时**${mainReaction.desc}**，配角A**${reactionA.desc}**，配角B**${reactionB.desc}**，配角C**${reactionC.desc}**`
        : `主角**${mainReaction.desc}**，周围配角反应各异：A**${reactionA.desc}**，B**${reactionB.desc}**，C**${reactionC.desc}**`;
      
      result += `### 🎬 镜号：[Shot ${index + 1}] | ⏱ 时长：${shotDuration}秒

**【📋 全局提示词配置】**：${customPromptAdditions || '无'}

---

**📖 对应原剧本**：${sentence.trim()}

**🗣️ 台词与多重反应**：${reactionText}

**【制作规格】**：电影胶片颗粒质感，高动态范围HDR色调，9:16竖屏，短剧爆款风格，情绪冲击力拉满

**【运镜·${template.name}】**：${template.cameraMovement}

**【景别·${template.shotSize}】**：${template.shotSize}

**【流畅构图·专业构图】**：${template.composition}

**💡 创意运镜与构图建议**：
1. 尝试低角度仰拍增强气势
2. 使用前景遮挡增加层次感
3. 快速变焦营造紧张感

**【场景·写实呈现】**：${sceneImages.length > 0 ? '参考上传的场景图，延续场景特征' : '金色玄幻风格场景，超写实渲染'}

**【人物动势】**：${motion === 'ultra' ? '极强动势，发丝和服装完全展开' : motion === 'high' ? '高动势，明显的运动能量' : '自然动势，写实风格'}

**【环境叙事·动态沉浸】**：场景材质纹理真实，光影动态投射，布料飘动，发丝飞舞

**【光色质感】**：${template.lighting}

**【剪辑·流畅】**：入点：前镜收尾；出点：情绪饱和；衔接自然

**🪄 即梦 Seedance 2.0 英文提示词**：
\`\`\`text
${prompt}, ${mainReaction.prompt}, ${reactionA.prompt}, ${reactionB.prompt}, ${reactionC.prompt}
\`\`\`

---

`;
    });

    setGeneratedPrompts(result);
    setIsGenerating(false);
  };

  const generatePrompts = async () => {
    if (!script.trim()) {
      setError('请先输入剧本内容');
      return;
    }
    
    // 离线模式直接生成
    if (offlineMode) {
      generateOfflinePrompts();
      return;
    }
    
    // 本地 AI 模式
    if (localAIMode) {
      if (localAIStatus !== 'loaded') {
        setError('本地 AI 模型尚未加载完成，请稍后再试');
        return;
      }
      generateLocalAIPrompts();
      return;
    }
    
    if (serverStatus !== 'ok') {
      setError('AI 服务未配置，请切换到离线模式或联系管理员');
      return;
    }
    setError('');
    setIsGenerating(true);
    setGeneratedPrompts(''); // Clear previous output for streaming

    const styleMap: Record<string, string> = { 'xh': '金色玄幻', 'xx': '仙侠飘渺', 'md': '魔都暗黑', 'gw': '古武热血' };
    const emotionMap: Record<string, string> = { 'max': '极致爆发', 'hi': '高度外放', 'mid': '中度戏剧' };
    const cameraMap: Record<string, string> = { 'side': '侧面/斜侧优先', 'mix': '混合运镜', 'epic': '史诗大景', 'intimate': '亲密特写', 'fpv': '第一人称视角', 'tracking': '动态跟拍', 'orbit': '环绕镜头' };
    const paceMap: Record<string, string> = { 'flow': '流畅节奏', 'cut': '快切节奏', 'epic': '史诗升格' };
    const motionMap: Record<string, string> = { 'ultra': '极强动势', 'high': '高动势', 'mid': '自然动势' };
    const fxMap: Record<string, string> = { 'rich': '华丽丰富', 'subtle': '点缀微光', 'none': '无特效纯实拍' };

    try {
      const promptText = `
你是一位顶级的抖音述评短剧分镜大师。请严格按照以下剧本，将其按时间顺序拆解为连续的、不重复的多个分镜，并生成专供【即梦 Seedance 2.0】使用的超详细英文提示词（Prompt）。

【🔴 核心痛点与强制规则 - 违背视为失败】：
1. 🚫 彻底拒绝重复，必须推进剧情：你必须按剧本时间线顺延拆解！每一个分镜必须是剧情的下一步。绝对不能在多个分镜中重复相同的台词、动作或提示词！如果剧本有5句话，你必须把这5句话分配到不同的分镜中，绝不能让5个分镜都在演同一句话！
2. ⏱️ 严格时长控制：所有分镜的时长相加，总时长【必须严格控制在 ${totalDuration}秒 之间】！请在每个分镜明确标注时长，并确保总和达标。
3. 🗣️ 台词与多重反应切镜：每个分镜必须明确写出“当前台词是谁说的”，说话时的【肢体辅助动作】是什么。并且，每个分镜必须增加对【至少3个不同配角】的反应镜头描述，并详细说明他们的微表情和情绪变化。
4. 🖼️ 严格遵循参考图与自定义名称：
   - 场景：必须先分析上传的场景参考图，分镜提示词里关于场景的描述一定要延续上传的参考图，不要出现莫须有的场景描述！如果用户自定义了场景名称，请在提示词中体现该场景特征。
   - 角色：必须延续参考图的特征，绝对不得随意捏造人物长相、服装。画面中绝对不要出现多余的无关人物。如果用户自定义了角色名称，请务必将该名称与角色特征绑定，并在生成的英文提示词中体现！
5. ✨ 精准且宏大的特效（VFX）：严格按照剧本，不是每个镜头都有特效！只有当剧本明确需要特效（如施法、爆发、打斗）时才添加。有特效的镜头，描述一定要宏伟、好看、壮观（参考“仙逆施法特效”），例如：“升腾的金色符文缠绕全身，爆发出耀眼的能量光柱，撕裂天空，形成巨大的金色漩涡”。确保特效描述与整体风格（金色、玄幻）一致。
6. 💡 创意运镜与构图：为每个生成的分镜，提供2-3个与当前选定运镜风格和构图手法相匹配的、更具创意的运镜和构图组合建议。
7. 🛑 附加全局提示词规则：用户提供的附加全局提示词必须且只能出现在【镜号标题处】，**绝对不要**将其放入最终生成的即梦 Seedance 2.0 英文提示词代码块中！

【🎬 即梦 Seedance 2.0 专属视觉与风格设定】：
- 🎭 人物性格与动作分析：在生成提示词前，请先深度分析剧本中每个人物的性格。根据他们的性格，为其设计符合身份的、不夸张但具有表现力的竖屏短剧肢体动作和说话方式。拒绝空洞的“浮夸表演”，必须具体到微表情和肢体细节！例如：“咬牙切齿的愤怒 (gnashing teeth in extreme anger)”、“难以置信的震惊 (eyes wide open in unbelievable shock)”。肢体动作必须细化，如“猛地后退一步 (suddenly stepping back)”、“双手紧握成拳 (clenching fists tightly)”。让动作与台词、剧情完美咬合！
- 🎥 顶级分镜组合与运镜细节：优化镜头衔接，运用推拉摇移跟等复杂运镜（e.g., rapid zoom in, slow panning, dynamic tracking shot）。多使用侧面拍摄（Side-angle shots）、低角度仰拍（Low-angle shot for dominance）、高角度俯拍（High-angle shot for vulnerability）来增强视觉冲击力。
- 💡 殿堂级光影表现：光影实时投射动态阴影 (real-time dynamic shadows and lighting)，强调体积光（Volumetric lighting）、丁达尔效应（Tyndall effect）、边缘轮廓光（Rim lighting）以及高反差的戏剧性光影（Dramatic high-contrast lighting）。
- 基础画质：Hyper-realistic rendering, 8K ultra HD, RAW cinematic tone, theatrical quality, real physical lighting, no cartoon feel, Douyin vertical screen 9:16. 超写实风格，玄幻风格感觉，画面极具视觉冲击力，构图美观，富有创意，给你赋予想象力的权限画面一定要真实，直给的画面不要压抑，大师级别的运镜。
- 动态与细节：场景材质纹理真实 (realistic textures and materials), 场景所有元素动态运动如布料飘动、发丝飞舞 (dynamic movement of all scene elements, e.g., cloth fluttering in the wind, hair blowing). 夸张的面部表情溢出屏幕的情绪。
- 排除项：画面中绝对不要出现任何字幕（No text, no subtitles）和BGM符号。不要出现多余的人物。

【⚙️ 当前用户动态参数配置】（必须严格根据这些参数调整你的分镜设计和英文提示词，不同的参数配置必须生成截然不同的提示词）：
1. 画面风格：${styleMap[style] || style}
2. 情绪张力：${emotionMap[emotion] || emotion}
3. 运镜风格：${cameraMap[camera] || camera}
4. 剪辑节奏：${paceMap[pace] || pace}
5. 人物动势：${motionMap[motion] || motion}
6. 特效密度：${fxMap[fx] || fx}
7. 单镜时长：${duration === '0' ? '智能动态' : duration + '秒'}
8. 分镜总时长：${totalDuration}秒
9. 剪辑标记：${markers === 'on' ? '开启' : '关闭'}
10. 附加全局提示词：${customPromptAdditions}

【📜 剧本内容】：
${script}

${characterAnalysis ? `【🎭 角色性格深度解析（作为生成提示词的参考）】：\n${characterAnalysis}\n` : ''}

【📝 输出格式要求】（请严格使用以下 Markdown 格式输出）：

### 🎬 镜号：[Shot 1] | ⏱ 时长：[X]秒

**【📋 全局提示词配置】**：${customPromptAdditions || '无'}

---

**📖 对应原剧本**：[摘录当前分镜对应的原剧本句子，证明你没有重复]

**🗣️ 台词与多重反应**：[例如：玄烬说话（歇斯底里的悲伤，眼泪甩出：爹爹的血脉已经断绝了，世间无人能治。） -> 反应镜头先切给震惊的林动，再切给冷笑的黑衣人，最后切给恐惧的村民，详细描述这至少3个配角的微表情和情绪变化]

**【制作规格】**：电影胶片颗粒质感，高动态范围HDR色调，9:16竖屏，短剧爆款风格，情绪冲击力拉满

**【运镜·[运镜手法]】**：[详细描述运镜，例如：摄影机在斜后侧45度强逆光位，人物整体呈轮廓光剪影，缓缓向侧前方推进旋转，从剪影过渡到半侧清晰近景，服饰边缘形成耀眼光边]

**【景别·[景别类型]】**：[详细描述景别，例如：medium shot，人物膝盖以上入画，清晰展现上身动作手势，表情可见动作可辨]

**【流畅构图·[构图手法]】**：[详细描述构图，例如：人物背面或侧面剪影置于竖屏对角线，大片留黑的负空间衬托冲击力]

**💡 创意运镜与构图建议**：[提供2-3个与当前选定运镜风格和构图手法相匹配的、更具创意的运镜和构图组合建议]

**【场景·写实呈现】**：依据剧本："[当前台词/动作]"；[结合参考图详细描述场景，例如：场景材质纹理真实，光影实时投射动态阴影；布料在气流中猎猎飘扬，光影随特效实时变化；超写实渲染，8K超高清，RAW电影色调，院线质感，真实物理光照，无卡通感，抖音竖屏9:16]

**【人物动势】**：[详细描述动势，例如：人物正处于运动弧线顶点，服饰和发丝都随动势展开，力量感与仪式感并存]

**【环境叙事·动态沉浸】**：依据剧本："[当前台词/动作]"；[详细描述环境，例如：从斜侧45度角呈现，人物轮廓在光线中勾勒出强烈动势，光影动态投射]

**【光色质感】**：[详细描述光色，例如：丁达尔散射：光束穿过环境形成散射，空气中微粒在光柱中漂浮运动，神圣感满溢；整体色调：高对比度，华美壮观，金色主调]

**【剪辑·流畅】**：入点：[例如：前镜余势收尾时]；出点：[例如：本镜情绪达到饱和时]；衔接自然，动作连贯，情绪递进

**🪄 即梦 Seedance 2.0 英文提示词**：
\`\`\`text
[此处填写极其详细的英文提示词，必须包含上述所有分析的视觉词汇、极致面部表情、细化肢体动作、复杂运镜、殿堂级光影、动态元素等。注意：绝对不要包含"附加全局提示词"的内容，不少于 80 个英文单词]
\`\`\`

---

（请以此类推，直到剧本结束，确保总时长在 ${totalDuration}秒 之间，绝对不许重复同一个镜头！）
`;

      const parts: any[] = [{ text: promptText }];

      charImages.forEach((img) => {
        const base64Data = img.data.split(',')[1];
        const mimeType = img.data.split(';')[0].split(':')[1];
        parts.push({ text: `[参考图：角色 - ${img.name}]` });
        parts.push({
          inlineData: { data: base64Data, mimeType }
        });
      });

      sceneImages.forEach((img) => {
        const base64Data = img.data.split(',')[1];
        const mimeType = img.data.split(';')[0].split(':')[1];
        parts.push({ text: `[参考图：场景 - ${img.name}]` });
        parts.push({
          inlineData: { data: base64Data, mimeType }
        });
      });

      // 使用 SSE 接收流式响应
      const response = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          script,
          fullScript,
          characterAnalysis,
          charImages,
          sceneImages,
          style,
          emotion,
          camera,
          pace,
          motion,
          fx,
          duration,
          totalDuration,
          markers,
          customPromptAdditions
        })
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || '生成失败');
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();
      let fullText = '';

      if (reader) {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          
          const chunk = decoder.decode(value);
          const lines = chunk.split('\n');
          
          for (const line of lines) {
            if (line.startsWith('data: ')) {
              const data = line.slice(6);
              if (data === '[DONE]') break;
              try {
                const parsed = JSON.parse(data);
                if (parsed.text) {
                  fullText += parsed.text;
                  setGeneratedPrompts(fullText);
                }
              } catch (e) {
                // 忽略解析错误
              }
            }
          }
        }
      }
    } catch (err: any) {
      handleError(err, '生成失败');
    } finally {
      setIsGenerating(false);
    }
  };

  const loadExample = () => {
    setFullScript("（雷雨交加的夜晚，破败的古庙内）\n林动（男主，眼神坚毅，浑身是血）死死盯着眼前的黑衣人。\n黑衣人（冷笑）：交出秘籍，留你全尸。\n林动擦去嘴角的血迹，拔出断剑：做梦！\n（林动暴起发难，剑光如龙，直逼黑衣人面门）\n（周围的村民吓得瑟瑟发抖，村长绝望地闭上了眼睛，小女孩躲在母亲怀里哭泣）");
    setScript("（雷雨交加的夜晚，破败的古庙内）\n林动（男主，眼神坚毅，浑身是血）死死盯着眼前的黑衣人。\n黑衣人（冷笑）：交出秘籍，留你全尸。\n林动擦去嘴角的血迹，拔出断剑：做梦！\n（林动暴起发难，剑光如龙，直逼黑衣人面门）");
  };

  return (
    <div className="min-h-screen bg-neutral-900 text-neutral-200 font-sans flex flex-col">
      {/* Header */}
      <header className="bg-neutral-950 border-b border-neutral-800 p-4 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center gap-3">
          <div className="bg-indigo-600 p-2 rounded-lg">
            <Clapperboard className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-white tracking-tight">短剧分镜导演台</h1>
            <span className="text-xs text-indigo-400 font-mono">PRO v13.0</span>
          </div>
        </div>
        <div className="flex items-center gap-4">
          {/* 模式选择器 */}
          <div className="flex items-center bg-neutral-800 rounded-lg p-1">
            <button
              onClick={() => { setOfflineMode(false); setLocalAIMode(false); }}
              className={`px-3 py-1.5 text-xs rounded-md transition-colors flex items-center gap-1.5 ${
                !offlineMode && !localAIMode
                  ? 'bg-indigo-600 text-white' 
                  : 'text-neutral-400 hover:text-white'
              }`}
              title="使用服务器 AI 服务"
            >
              <Wifi className="w-3.5 h-3.5" />
              在线
            </button>
            <button
              onClick={() => { setOfflineMode(true); setLocalAIMode(false); }}
              className={`px-3 py-1.5 text-xs rounded-md transition-colors flex items-center gap-1.5 ${
                offlineMode && !localAIMode
                  ? 'bg-purple-600 text-white' 
                  : 'text-neutral-400 hover:text-white'
              }`}
              title="使用预设模板"
            >
              <WifiOff className="w-3.5 h-3.5" />
              模板
            </button>
            <button
              onClick={() => { setOfflineMode(false); setLocalAIMode(true); }}
              className={`px-3 py-1.5 text-xs rounded-md transition-colors flex items-center gap-1.5 ${
                localAIMode
                  ? 'bg-emerald-600 text-white' 
                  : 'text-neutral-400 hover:text-white'
              }`}
              title="使用浏览器本地 AI 模型"
            >
              {localAIStatus === 'loading' ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : 
               localAIStatus === 'loaded' ? <CheckCircle2 className="w-3.5 h-3.5" /> : 
               localAIStatus === 'error' ? <Settings className="w-3.5 h-3.5 text-red-400" /> :
               <Camera className="w-3.5 h-3.5" />}
              本地 AI
            </button>
          </div>
          
          {/* 本地 AI 加载进度 - 仅本地 AI 模式显示 */}
          {localAIMode && localAIStatus !== 'loaded' && (
            <div className={`px-3 py-1.5 text-xs rounded-lg flex items-center gap-1.5 border ${
              localAIStatus === 'error' 
                ? 'bg-red-500/20 text-red-400 border-red-500/30' 
                : 'bg-amber-500/20 text-amber-400 border-amber-500/30'
            }`}>
              {localAIStatus === 'loading' ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : 
               <Settings className="w-3.5 h-3.5" />}
              <span className="max-w-[200px] truncate">{localAIProgress || '准备中...'}</span>
            </div>
          )}
          
          {/* 服务器状态指示器 - 仅在线模式显示 */}
          {!offlineMode && !localAIMode && (
            <div className={`px-3 py-1.5 text-xs rounded-lg flex items-center gap-1.5 border ${
              serverStatus === 'ok' 
                ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' 
                : serverStatus === 'checking'
                ? 'bg-amber-500/20 text-amber-400 border-amber-500/30'
                : 'bg-red-500/20 text-red-400 border-red-500/30'
            }`}>
              {serverStatus === 'ok' ? <CheckCircle2 className="w-3.5 h-3.5" /> : 
               serverStatus === 'checking' ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : 
               <Settings className="w-3.5 h-3.5" />}
              {serverStatus === 'ok' ? 'AI 服务正常' : 
               serverStatus === 'checking' ? '检查中...' : 
               '未配置'}
            </div>
          )}
          <span className="px-2 py-1 bg-amber-500/20 text-amber-400 text-xs rounded border border-amber-500/30 font-medium">⚡ 大师级运镜</span>
          <span className="px-2 py-1 bg-blue-500/20 text-blue-400 text-xs rounded border border-blue-500/30 font-medium">9:16 竖屏专属</span>
          <div className="flex items-center gap-2 bg-neutral-800 rounded-lg p-1 ml-4">
            <button onClick={() => setFontSize(Math.max(12, fontSize - 2))} className="p-1.5 hover:bg-neutral-700 rounded text-neutral-400 hover:text-white transition-colors"><Minus className="w-4 h-4" /></button>
            <span className="text-xs font-mono w-6 text-center">{fontSize}px</span>
            <button onClick={() => setFontSize(Math.min(24, fontSize + 2))} className="p-1.5 hover:bg-neutral-700 rounded text-neutral-400 hover:text-white transition-colors"><Plus className="w-4 h-4" /></button>
          </div>
        </div>
      </header>

      {/* 服务器状态提示 */}
      {serverStatus === 'error' && (
        <div className="bg-red-900/20 border-b border-red-800/50 p-4">
          <div className="max-w-4xl mx-auto flex items-center gap-3">
            <Settings className="w-5 h-5 text-red-400" />
            <span className="text-red-400 text-sm">
              AI 服务未配置，请联系管理员设置 GEMINI_API_KEY 环境变量
            </span>
            <a
              href="https://aistudio.google.com/app/apikey"
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-1 bg-red-600 hover:bg-red-500 text-white text-xs rounded transition-colors ml-auto"
            >
              获取 API Key
            </a>
          </div>
        </div>
      )}

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <aside className="w-80 bg-neutral-900 border-r border-neutral-800 overflow-y-auto p-6 flex flex-col gap-8 custom-scrollbar">
          {/* Style & Emotion */}
          <section>
            <h2 className="text-sm font-semibold text-neutral-400 uppercase tracking-wider mb-4 flex items-center gap-2">
              <Sparkles className="w-4 h-4" /> 风格 & 情绪
            </h2>
            <div className="space-y-4">
              <div>
                <label className="block text-xs text-neutral-500 mb-1.5">画面风格</label>
                <select value={style} onChange={(e) => setStyle(e.target.value)} className="w-full bg-neutral-950 border border-neutral-800 rounded-lg px-3 py-2 text-sm text-neutral-200 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all">
                  <option value="xh">金色玄幻（主推）</option>
                  <option value="xx">仙侠飘渺</option>
                  <option value="md">魔都暗黑</option>
                  <option value="gw">古武热血</option>
                </select>
              </div>
              <div>
                <label className="block text-xs text-neutral-500 mb-1.5">情绪张力</label>
                <select value={emotion} onChange={(e) => setEmotion(e.target.value)} className="w-full bg-neutral-950 border border-neutral-800 rounded-lg px-3 py-2 text-sm text-neutral-200 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all">
                  <option value="max">极致爆发（爆款）</option>
                  <option value="hi">高度外放</option>
                  <option value="mid">中度戏剧</option>
                </select>
              </div>
            </div>
          </section>

          {/* Camera & Pace */}
          <section>
            <h2 className="text-sm font-semibold text-neutral-400 uppercase tracking-wider mb-4 flex items-center gap-2">
              <Clapperboard className="w-4 h-4" /> 大师运镜
            </h2>
            <div className="space-y-4">
              <div>
                <div className="flex flex-wrap gap-2 mb-3">
                  <button onClick={() => { setCamera('mix'); setPace('flow'); setMotion('mid'); }} className="px-2 py-1 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs rounded border border-neutral-700 transition-colors">
                    经典运镜
                  </button>
                  <button onClick={() => { setCamera('intimate'); setPace('cut'); setMotion('high'); }} className="px-2 py-1 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs rounded border border-neutral-700 transition-colors">
                    悬疑惊悚
                  </button>
                  <button onClick={() => { setCamera('side'); setPace('cut'); setMotion('ultra'); }} className="px-2 py-1 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs rounded border border-neutral-700 transition-colors">
                    动作大片
                  </button>
                </div>
                <label className="block text-xs text-neutral-500 mb-1.5">运镜风格偏好</label>
                <select value={camera} onChange={(e) => setCamera(e.target.value)} className="w-full bg-neutral-950 border border-neutral-800 rounded-lg px-3 py-2 text-sm text-neutral-200 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all">
                  <option value="side">侧面/斜侧优先（爆款）</option>
                  <option value="mix">混合运镜（导演自决）</option>
                  <option value="epic">史诗大景（全能镜库）</option>
                  <option value="intimate">亲密特写（近景优先）</option>
                  <option value="fpv">第一人称视角 (FPV)</option>
                  <option value="tracking">动态跟拍 (Tracking)</option>
                  <option value="orbit">环绕镜头 (Orbiting)</option>
                </select>
              </div>
              <div>
                <label className="block text-xs text-neutral-500 mb-1.5">剪辑节奏</label>
                <select value={pace} onChange={(e) => setPace(e.target.value)} className="w-full bg-neutral-950 border border-neutral-800 rounded-lg px-3 py-2 text-sm text-neutral-200 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all">
                  <option value="cut">快切节奏（短平快）</option>
                  <option value="flow">流畅节奏（标准短剧）</option>
                  <option value="epic">史诗升格（慢镜）</option>
                </select>
              </div>
            </div>
          </section>

          {/* Advanced Params */}
          <section>
            <h2 className="text-sm font-semibold text-neutral-400 uppercase tracking-wider mb-4 flex items-center gap-2">
              <Settings className="w-4 h-4" /> 高级参数
            </h2>
            <div className="space-y-4">
              <div>
                <label className="block text-xs text-neutral-500 mb-1.5">人物动势强度</label>
                <select value={motion} onChange={(e) => setMotion(e.target.value)} className="w-full bg-neutral-950 border border-neutral-800 rounded-lg px-3 py-2 text-sm text-neutral-200 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all">
                  <option value="ultra">极强动势（爆款首选）</option>
                  <option value="high">高动势（流畅运镜）</option>
                  <option value="mid">自然动势（写实）</option>
                </select>
              </div>
              <div>
                <label className="block text-xs text-neutral-500 mb-1.5">特效密度</label>
                <select value={fx} onChange={(e) => setFx(e.target.value)} className="w-full bg-neutral-950 border border-neutral-800 rounded-lg px-3 py-2 text-sm text-neutral-200 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all">
                  <option value="rich">丰富特效（爆款）</option>
                  <option value="mid">适量特效（平衡）</option>
                  <option value="clean">极简特效（写实）</option>
                </select>
              </div>
              <div>
                <label className="block text-xs text-neutral-500 mb-1.5">单镜时长</label>
                <select value={duration} onChange={(e) => setDuration(e.target.value)} className="w-full bg-neutral-950 border border-neutral-800 rounded-lg px-3 py-2 text-sm text-neutral-200 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all">
                  <option value="0">智能动态（推荐）</option>
                  <option value="10">10秒</option>
                  <option value="12">12秒</option>
                  <option value="15">15秒</option>
                  <option value="18">18秒</option>
                  <option value="20">20秒</option>
                </select>
              </div>
              <div>
                <label className="block text-xs text-neutral-500 mb-1.5">剪辑标记</label>
                <select value={markers} onChange={(e) => setMarkers(e.target.value)} className="w-full bg-neutral-950 border border-neutral-800 rounded-lg px-3 py-2 text-sm text-neutral-200 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all">
                  <option value="on">开启（含入出点）</option>
                  <option value="off">关闭（纯提示词）</option>
                </select>
              </div>
              <div className="col-span-2">
                <label className="block text-xs text-neutral-500 mb-1.5">分镜总时长</label>
                <select value={totalDuration} onChange={(e) => setTotalDuration(e.target.value)} className="w-full bg-neutral-950 border border-neutral-800 rounded-lg px-3 py-2 text-sm text-neutral-200 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all">
                  <option value="60-90">60-90秒 (1-1.5分钟)</option>
                  <option value="90-120">90-120秒 (1.5-2分钟)</option>
                  <option value="120-180">120-180秒 (2-3分钟)</option>
                  <option value="180-210">180-210秒 (3-3.5分钟)</option>
                  <option value="210-300">210-300秒 (3.5-5分钟)</option>
                </select>
              </div>
            </div>
          </section>
        </aside>

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto p-6 bg-neutral-950 custom-scrollbar">
          <div className="max-w-4xl mx-auto space-y-6">
            
            {/* Full Script Input */}
            <div className="bg-neutral-900 border border-neutral-800 rounded-xl overflow-hidden shadow-sm">
              <div className="bg-neutral-800/50 px-4 py-3 border-b border-neutral-800 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <FileText className="w-5 h-5 text-emerald-400" />
                  <h3 className="font-medium text-neutral-200">完整剧本（用于角色深度分析）</h3>
                </div>
                <div className="flex items-center gap-2">
                  <label className="cursor-pointer px-3 py-1.5 bg-neutral-700 hover:bg-neutral-600 text-neutral-200 text-xs rounded-lg transition-colors flex items-center gap-1.5">
                    <Upload className="w-3.5 h-3.5" />
                    上传剧本文件
                    <input 
                      type="file" 
                      accept=".txt,.doc,.docx,.pdf,.md" 
                      className="hidden" 
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          const reader = new FileReader();
                          reader.onload = (event) => {
                            const text = event.target?.result as string;
                            setFullScript(text);
                          };
                          // 尝试 UTF-8 编码，如果失败会自动尝试其他编码
                          reader.readAsText(file, 'UTF-8');
                        }
                      }}
                    />
                  </label>
                  <button 
                    onClick={analyzeFullScript}
                    disabled={isAnalyzingCharacters || !fullScript.trim()}
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 disabled:bg-neutral-800 disabled:text-neutral-500 text-white text-xs rounded-lg transition-colors flex items-center gap-1.5"
                  >
                    {isAnalyzingCharacters ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
                    {isAnalyzingCharacters ? '分析中...' : '一键分析角色'}
                  </button>
                </div>
              </div>
              <div className="p-4">
                <textarea 
                  value={fullScript}
                  onChange={(e) => setFullScript(e.target.value)}
                  placeholder="粘贴完整剧本内容或上传剧本文件(.txt, .doc, .docx, .pdf, .md)，AI将深度解析所有角色的性格、外貌和习惯动作，让后续分镜提示词更精准..."
                  className="w-full h-32 bg-neutral-950 border border-neutral-800 rounded-lg p-4 text-neutral-200 placeholder-neutral-600 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all resize-y"
                  style={{ fontSize: `${fontSize}px` }}
                />
                {characterAnalysis && (
                  <div className="mt-4 p-4 bg-emerald-900/20 border border-emerald-800/50 rounded-lg">
                    <h4 className="text-emerald-400 text-sm font-medium mb-2 flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4" /> 角色解析完成（将自动应用于分镜生成）
                    </h4>
                    <div className="text-sm text-neutral-300 max-h-40 overflow-y-auto custom-scrollbar prose prose-invert prose-sm">
                      <ReactMarkdown>{characterAnalysis}</ReactMarkdown>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Script Input */}
            <div className="bg-neutral-900 border border-neutral-800 rounded-xl overflow-hidden shadow-sm">
              <div className="bg-neutral-800/50 px-4 py-3 border-b border-neutral-800 flex items-center gap-2">
                <FileText className="w-5 h-5 text-indigo-400" />
                <h3 className="font-medium text-neutral-200">当前分镜剧本</h3>
              </div>
              <div className="p-4">
                <textarea 
                  value={script}
                  onChange={(e) => setScript(e.target.value)}
                  placeholder="粘贴当前需要生成分镜的剧本片段..."
                  className="w-full h-48 bg-neutral-950 border border-neutral-800 rounded-lg p-4 text-neutral-200 placeholder-neutral-600 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all resize-y"
                  style={{ fontSize: `${fontSize}px` }}
                />
                <div className="flex justify-between items-center mt-3">
                  <span className="text-xs text-neutral-500 font-mono">{script.length} 字</span>
                  <div className="flex gap-4">
                    <button 
                      onClick={analyzeCameraStyle} 
                      disabled={isAnalyzingCamera || !script.trim()}
                      className="text-xs text-amber-400 hover:text-amber-300 disabled:text-neutral-600 transition-colors flex items-center gap-1"
                    >
                      {isAnalyzingCamera ? <Loader2 className="w-3 h-3 animate-spin" /> : <Camera className="w-3 h-3" />}
                      智能推荐运镜
                    </button>
                    <button onClick={loadExample} className="text-xs text-indigo-400 hover:text-indigo-300 transition-colors flex items-center gap-1">
                      <Sparkles className="w-3 h-3" /> 载入示例剧本
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Custom Prompt Additions */}
            <div className="bg-neutral-900 border border-neutral-800 rounded-xl overflow-hidden shadow-sm">
              <div className="bg-neutral-800/50 px-4 py-3 border-b border-neutral-800 flex items-center gap-2">
                <Type className="w-5 h-5 text-amber-400" />
                <h3 className="font-medium text-neutral-200">附加全局提示词 (Global Prompts)</h3>
              </div>
              <div className="p-4">
                <div className="space-y-2 mb-3">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-xs text-neutral-500 w-16">画面风格:</span>
                    <button onClick={() => setCustomPromptAdditions(prev => prev + (prev ? ', ' : '') + 'hyper-realistic style, fantasy style feel, highly visually impactful, beautiful composition')} className="px-2 py-1 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs rounded border border-neutral-700 transition-colors">
                      玄幻写实
                    </button>
                    <button onClick={() => setCustomPromptAdditions(prev => prev + (prev ? ', ' : '') + 'dark cinematic, moody lighting, cyberpunk undertones, neon glow')} className="px-2 py-1 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs rounded border border-neutral-700 transition-colors">
                      暗黑赛博
                    </button>
                    <button onClick={() => setCustomPromptAdditions(prev => prev + (prev ? ', ' : '') + 'traditional chinese ink painting style, wuxia, ethereal, misty mountains')} className="px-2 py-1 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs rounded border border-neutral-700 transition-colors">
                      水墨武侠
                    </button>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-xs text-neutral-500 w-16">情绪张力:</span>
                    <button onClick={() => setCustomPromptAdditions(prev => prev + (prev ? ', ' : '') + 'extreme sadness, tears streaming down face, heartbreaking expression, red eyes')} className="px-2 py-1 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs rounded border border-neutral-700 transition-colors">
                      极度悲伤
                    </button>
                    <button onClick={() => setCustomPromptAdditions(prev => prev + (prev ? ', ' : '') + 'ecstasy, wild laughter, eyes wide with manic joy, uncontrollable excitement')} className="px-2 py-1 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs rounded border border-neutral-700 transition-colors">
                      狂喜
                    </button>
                    <button onClick={() => setCustomPromptAdditions(prev => prev + (prev ? ', ' : '') + 'pure terror, trembling, pale face, shrinking back in fear, wide terrified eyes')} className="px-2 py-1 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs rounded border border-neutral-700 transition-colors">
                      恐惧
                    </button>
                    <button onClick={() => setCustomPromptAdditions(prev => prev + (prev ? ', ' : '') + 'gnashing teeth in extreme anger, furious glare, veins popping')} className="px-2 py-1 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs rounded border border-neutral-700 transition-colors">
                      暴怒
                    </button>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-xs text-neutral-500 w-16">运镜风格:</span>
                    <button onClick={() => setCustomPromptAdditions(prev => prev + (prev ? ', ' : '') + 'master-level camera movement, dynamic tracking shot, rapid zoom in')} className="px-2 py-1 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs rounded border border-neutral-700 transition-colors">
                      大师动态
                    </button>
                    <button onClick={() => setCustomPromptAdditions(prev => prev + (prev ? ', ' : '') + 'slow panning, steady cam, majestic wide shot, cinematic framing')} className="px-2 py-1 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs rounded border border-neutral-700 transition-colors">
                      平稳宏大
                    </button>
                    <button onClick={() => setCustomPromptAdditions(prev => prev + (prev ? ', ' : '') + 'dutch angle, shaky cam, chaotic movement')} className="px-2 py-1 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs rounded border border-neutral-700 transition-colors">
                      倾斜手持
                    </button>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-xs text-neutral-500 w-16">剪辑节奏:</span>
                    <button onClick={() => setCustomPromptAdditions(prev => prev + (prev ? ', ' : '') + 'fast-paced editing, quick cuts, high energy')} className="px-2 py-1 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs rounded border border-neutral-700 transition-colors">
                      快节奏
                    </button>
                    <button onClick={() => setCustomPromptAdditions(prev => prev + (prev ? ', ' : '') + 'slow motion, dramatic pauses, lingering shots')} className="px-2 py-1 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs rounded border border-neutral-700 transition-colors">
                      慢放抒情
                    </button>
                    <button onClick={() => setCustomPromptAdditions('')} className="px-2 py-1 bg-red-900/20 hover:bg-red-900/40 text-red-400 text-xs rounded border border-red-900/30 transition-colors ml-auto">
                      清空全部
                    </button>
                  </div>
                </div>
                <textarea 
                  value={customPromptAdditions}
                  onChange={(e) => setCustomPromptAdditions(e.target.value)}
                  placeholder="输入需要附加到每个分镜的全局提示词（支持自定义组合）..."
                  className="w-full h-24 bg-neutral-950 border border-neutral-800 rounded-lg p-3 text-neutral-300 text-sm placeholder-neutral-600 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition-all resize-y"
                />
              </div>
            </div>

            {/* Image References */}
            <div className="grid grid-cols-2 gap-6">
              {/* Character Images */}
              <div className="bg-neutral-900 border border-neutral-800 rounded-xl overflow-hidden shadow-sm">
                <div className="bg-neutral-800/50 px-4 py-3 border-b border-neutral-800 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <ImageIcon className="w-5 h-5 text-emerald-400" />
                    <h3 className="font-medium text-neutral-200">角色参考图</h3>
                  </div>
                  <label className="cursor-pointer text-xs bg-neutral-800 hover:bg-neutral-700 px-2 py-1 rounded text-neutral-300 transition-colors flex items-center gap-1">
                    <Upload className="w-3 h-3" /> 上传
                    <input type="file" multiple accept="image/*" className="hidden" onChange={(e) => handleImageUpload(e, setCharImages, '角色')} />
                  </label>
                </div>
                <div className="p-4">
                  {charImages.length === 0 ? (
                    <div className="h-24 border-2 border-dashed border-neutral-800 rounded-lg flex items-center justify-center text-neutral-600 text-sm">
                      暂无角色参考图
                    </div>
                  ) : (
                    <div className="flex gap-3 overflow-x-auto pb-2 custom-scrollbar">
                      {charImages.map((img, i) => (
                        <div key={img.id} className="flex flex-col gap-1 flex-shrink-0 w-24">
                          <div className="relative w-24 h-24 rounded-lg overflow-hidden border border-neutral-700 group">
                            <img src={img.data} alt={img.name} className="w-full h-full object-cover" />
                            <button onClick={() => setCharImages(prev => prev.filter((_, idx) => idx !== i))} className="absolute top-1 right-1 bg-black/60 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity">
                              <Minus className="w-3 h-3" />
                            </button>
                          </div>
                          <input 
                            type="text" 
                            value={img.name}
                            onChange={(e) => {
                              const newImages = [...charImages];
                              newImages[i].name = e.target.value;
                              setCharImages(newImages);
                            }}
                            className="w-full bg-neutral-800 border border-neutral-700 rounded px-1.5 py-1 text-xs text-center text-neutral-300 focus:outline-none focus:border-indigo-500"
                            placeholder="角色名"
                          />
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Scene Images */}
              <div className="bg-neutral-900 border border-neutral-800 rounded-xl overflow-hidden shadow-sm">
                <div className="bg-neutral-800/50 px-4 py-3 border-b border-neutral-800 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <ImageIcon className="w-5 h-5 text-amber-400" />
                    <h3 className="font-medium text-neutral-200">场景参考图</h3>
                  </div>
                  <label className="cursor-pointer text-xs bg-neutral-800 hover:bg-neutral-700 px-2 py-1 rounded text-neutral-300 transition-colors flex items-center gap-1">
                    <Upload className="w-3 h-3" /> 上传
                    <input type="file" multiple accept="image/*" className="hidden" onChange={(e) => handleImageUpload(e, setSceneImages, '场景')} />
                  </label>
                </div>
                <div className="p-4">
                  {sceneImages.length === 0 ? (
                    <div className="h-24 border-2 border-dashed border-neutral-800 rounded-lg flex items-center justify-center text-neutral-600 text-sm">
                      暂无场景参考图
                    </div>
                  ) : (
                    <div className="flex gap-3 overflow-x-auto pb-2 custom-scrollbar">
                      {sceneImages.map((img, i) => (
                        <div key={img.id} className="flex flex-col gap-1 flex-shrink-0 w-24">
                          <div className="relative w-24 h-24 rounded-lg overflow-hidden border border-neutral-700 group">
                            <img src={img.data} alt={img.name} className="w-full h-full object-cover" />
                            <button onClick={() => setSceneImages(prev => prev.filter((_, idx) => idx !== i))} className="absolute top-1 right-1 bg-black/60 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity">
                              <Minus className="w-3 h-3" />
                            </button>
                          </div>
                          <input 
                            type="text" 
                            value={img.name}
                            onChange={(e) => {
                              const newImages = [...sceneImages];
                              newImages[i].name = e.target.value;
                              setSceneImages(newImages);
                            }}
                            className="w-full bg-neutral-800 border border-neutral-700 rounded px-1.5 py-1 text-xs text-center text-neutral-300 focus:outline-none focus:border-indigo-500"
                            placeholder="场景名"
                          />
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* AI Analysis */}
            <div className="bg-neutral-900 border border-neutral-800 rounded-xl overflow-hidden shadow-sm">
              <div className="bg-neutral-800/50 px-4 py-3 border-b border-neutral-800 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-purple-400" />
                  <h3 className="font-medium text-neutral-200">AI深度解析剧本</h3>
                </div>
                <button 
                  onClick={analyzeScript}
                  disabled={isAnalyzing || !script.trim()}
                  className="px-3 py-1.5 bg-purple-600 hover:bg-purple-500 disabled:bg-neutral-800 disabled:text-neutral-500 text-white text-xs rounded-lg transition-colors flex items-center gap-1.5 font-medium"
                >
                  {isAnalyzing ? <RefreshCw className="w-3 h-3 animate-spin" /> : <Play className="w-3 h-3" />}
                  {isAnalyzing ? '解析中...' : '开始解析'}
                </button>
              </div>
              {analysisResult && (
                <div className="p-4 bg-neutral-950/50 border-t border-neutral-800/50">
                  <div className="prose prose-invert prose-sm max-w-none whitespace-pre-wrap" style={{ fontSize: `${fontSize}px` }}>
                    {analysisResult}
                  </div>
                </div>
              )}
            </div>

            {/* Error Message */}
            {error && (
              <div className="bg-red-500/10 border border-red-500/20 text-red-400 px-4 py-3 rounded-lg text-sm">
                {error}
              </div>
            )}

            {/* Main Action */}
            <div className="flex justify-center py-4">
              <button 
                onClick={generatePrompts}
                disabled={isGenerating || !script.trim()}
                className="px-8 py-4 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 disabled:from-neutral-800 disabled:to-neutral-800 disabled:text-neutral-500 text-white rounded-xl font-bold text-lg shadow-lg shadow-indigo-500/20 transition-all flex items-center gap-3 transform hover:scale-[1.02] active:scale-[0.98]"
              >
                {isGenerating ? <RefreshCw className="w-5 h-5 animate-spin" /> : <Sparkles className="w-5 h-5" />}
                {isGenerating ? '导演级智能分镜生成中...' : '一键生成爆款分镜提示词'}
              </button>
            </div>

            {/* Output */}
            {generatedPrompts && (
              <div className="bg-neutral-900 border border-neutral-800 rounded-xl overflow-hidden shadow-sm">
                <div className="bg-neutral-800/50 px-4 py-3 border-b border-neutral-800 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <FileText className="w-5 h-5 text-emerald-400" />
                    <h3 className="font-medium text-neutral-200">生成结果</h3>
                  </div>
                  <div className="flex gap-2">
                    <button 
                      onClick={() => navigator.clipboard.writeText(generatedPrompts)}
                      className="p-1.5 bg-neutral-800 hover:bg-neutral-700 rounded text-neutral-300 transition-colors"
                      title="复制全部"
                    >
                      <Copy className="w-4 h-4" />
                    </button>
                  </div>
                </div>
                <div className="p-6 bg-neutral-950">
                  <div className="prose prose-invert max-w-none leading-relaxed text-neutral-300" style={{ fontSize: `${fontSize}px` }}>
                    <ReactMarkdown
                      components={{
                        h3: ({node, children, ...props}) => {
                          // 提取镜号信息用于复制
                          const shotText = String(children);
                          return (
                            <div className="mt-10 mb-4">
                              <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
                                <h3 className="text-xl font-bold text-indigo-400 flex items-center gap-2 m-0" {...props}>
                                  {children}
                                </h3>
                                <CopyButton text={shotText} label="复制镜号" />
                              </div>
                            </div>
                          );
                        },
                        p: ({node, children, ...props}) => {
                          const text = String(children);
                          // 为全局提示词配置添加复制按钮
                          if (text.includes('【📋 全局提示词配置】')) {
                            return (
                              <div className="bg-amber-900/20 border border-amber-800/50 rounded-lg p-3 my-4">
                                <div className="flex items-center justify-between mb-2">
                                  <span className="text-amber-400 font-semibold text-sm">📋 全局提示词配置</span>
                                  <CopyButton 
                                    text={text.replace('**【📋 全局提示词配置】**：', '').replace('【📋 全局提示词配置】：', '')} 
                                    label="复制全局提示词" 
                                  />
                                </div>
                                <p className="text-neutral-300 text-sm m-0" {...props}>{children}</p>
                              </div>
                            );
                          }
                          // 为每个分镜的中文内容添加复制按钮
                          if (text.includes('对应原剧本') || text.includes('台词与多重反应') || text.includes('制作规格') || 
                              text.includes('运镜') || text.includes('景别') || text.includes('构图') || 
                              text.includes('场景') || text.includes('人物动势') || text.includes('环境叙事') || 
                              text.includes('光色质感') || text.includes('剪辑')) {
                            return (
                              <div className="flex items-start gap-2 group">
                                <p className="flex-1 m-0" {...props}>{children}</p>
                                <CopyButton text={text} label="复制" />
                              </div>
                            );
                          }
                          return <p {...props}>{children}</p>;
                        },
                        hr: ({node, ...props}) => (
                          <hr className="border-neutral-800 my-6" {...props} />
                        ),
                        ul: ({node, ...props}) => (
                          <ul className="space-y-2 my-4 list-none pl-0" {...props} />
                        ),
                        li: ({node, children, ...props}) => {
                          const text = String(children);
                          // 为列表项添加复制功能
                          return (
                            <li className="flex items-start gap-2 bg-neutral-900/50 p-3 rounded-lg border border-neutral-800/50 group">
                              <span className="flex-1">{children}</span>
                              <CopyButton text={text} label="复制" />
                            </li>
                          );
                        },
                        strong: ({node, ...props}) => (
                          <strong className="text-emerald-400 font-semibold min-w-max" {...props} />
                        ),
                        code: CodeBlock,
                      }}
                    >
                      {generatedPrompts}
                    </ReactMarkdown>
                  </div>
                </div>
              </div>
            )}

          </div>
        </main>
      </div>
    </div>
  );
}
