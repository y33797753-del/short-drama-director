// 预设分镜模板 - 无需 AI 即可生成分镜

export interface ShotTemplate {
  name: string;
  cameraMovement: string;
  shotSize: string;
  composition: string;
  lighting: string;
  prompt: string;
}

// 运镜风格模板
export const cameraTemplates: Record<string, ShotTemplate[]> = {
  side: [
    {
      name: "侧面对话镜头",
      cameraMovement: "侧面45度角拍摄，摄影机缓缓推进，从 medium shot 过渡到 close-up",
      shotSize: "Medium shot 转 Close-up",
      composition: "人物位于画面左侧1/3处，右侧留白形成负空间，增强对话张力",
      lighting: "侧逆光勾勒人物轮廓，面部柔和补光，形成戏剧性的明暗对比",
      prompt: "Side-angle shot at 45 degrees, camera slowly pushing in from medium shot to close-up, character positioned at left third of frame, negative space on right, rim lighting creating dramatic silhouette, soft fill light on face, 9:16 vertical format, cinematic quality"
    },
    {
      name: "侧面情绪爆发",
      cameraMovement: "低角度侧面仰拍，摄影机快速推近捕捉微表情",
      shotSize: "Extreme close-up",
      composition: "人物占据画面80%，背景虚化，强调情绪冲击力",
      lighting: "强烈的侧光，一半脸在阴影中，增强戏剧张力",
      prompt: "Low-angle side shot looking up, rapid push-in to extreme close-up, subject occupies 80% of frame, background heavily blurred, intense side lighting with half face in shadow, dramatic chiaroscuro effect, 9:16 vertical format, hyper-realistic rendering"
    }
  ],
  mix: [
    {
      name: "混合运镜开场",
      cameraMovement: "开场 wide shot 缓慢下摇，接 medium shot 横移",
      shotSize: "Wide shot 转 Medium shot",
      composition: "三分法构图，人物与环境平衡",
      lighting: "自然光为主，体积光营造氛围",
      prompt: "Opening wide shot slow tilt down, transitioning to medium shot pan, rule of thirds composition, balanced subject and environment, natural lighting with volumetric light rays, atmospheric depth, 9:16 vertical format, film grain texture"
    }
  ],
  epic: [
    {
      name: "史诗大景",
      cameraMovement: "航拍式 wide shot 缓慢环绕",
      shotSize: "Extreme wide shot",
      composition: "人物渺小置于宏大场景中，强调环境气势",
      lighting: "金色时刻光线，丁达尔效应",
      prompt: "Aerial-style extreme wide shot slow orbit, tiny figure in vast epic landscape, golden hour lighting with Tyndall effect rays piercing through atmosphere, majestic scale, 8K ultra HD, 9:16 vertical format, RAW cinematic tone"
    }
  ],
  intimate: [
    {
      name: "亲密特写",
      cameraMovement: "极近距离 static shot，焦点在眼神",
      shotSize: "Extreme close-up",
      composition: "眼睛位于画面上1/3处，浅景深",
      lighting: "柔和的环形补光，眼神光",
      prompt: "Extreme close-up static shot, focus on eyes positioned at upper third, shallow depth of field with creamy bokeh, soft ring light with catchlights in eyes, intimate and emotional, skin texture detail, 9:16 vertical format, hyper-realistic"
    }
  ],
  fpv: [
    {
      name: "第一人称视角",
      cameraMovement: "POV 手持晃动效果，模拟人眼视角",
      shotSize: "POV perspective",
      composition: "主观视角，前景有遮挡物增加层次",
      lighting: "现场光，真实感",
      prompt: "First-person POV perspective with subtle handheld shake, foreground elements creating depth layers, available lighting for realism, immersive subjective view, slight motion blur on edges, 9:16 vertical format, documentary style"
    }
  ],
  tracking: [
    {
      name: "动态跟拍",
      cameraMovement: "侧面 tracking shot，与人物同速移动",
      shotSize: "Medium shot",
      composition: "人物在画面中央，背景流动",
      lighting: "运动中的动态光影",
      prompt: "Side tracking shot matching subject speed, subject centered with flowing background motion blur, dynamic lighting changing as movement progresses, sense of speed and urgency, motion trails, 9:16 vertical format, action movie quality"
    }
  ],
  orbit: [
    {
      name: "环绕镜头",
      cameraMovement: "360度环绕，展现人物气场",
      shotSize: "Medium shot 转 Close-up",
      composition: "人物始终位于画面中心",
      lighting: "环绕过程中光影变化",
      prompt: "360-degree orbiting shot around subject, medium shot transitioning to close-up, subject always centered, dramatic lighting changes during orbit, showcasing character aura and presence, cinematic grandeur, 9:16 vertical format, smooth professional camera movement"
    }
  ]
};

// 情绪模板 - 多样化反应镜头
export const emotionTemplates: Record<string, string> = {
  max: "extreme emotional outburst, veins popping, tears streaming, hysterical expression, maximum dramatic intensity",
  hi: "highly expressive, visible emotional waves, passionate delivery, strong facial expressions",
  mid: "moderate dramatic expression, controlled emotion, natural acting style"
};

// 多样化反应镜头模板 - 根据剧本情绪变化
export const reactionTemplates = {
  // 震惊/恐惧反应
  shock: [
    { desc: "瞳孔放大，全身僵硬", prompt: "pupils dilated, body frozen stiff, jaw slightly dropped, cold sweat on forehead" },
    { desc: "后退踉跄，手捂胸口", prompt: "stumbling backward, hand clutching chest, gasping for air, face pale with shock" },
    { desc: "瞪大眼睛，呼吸急促", prompt: "eyes wide open staring, rapid breathing, trembling lips, disbelief expression" },
    { desc: "瘫软倒地，眼神空洞", prompt: "collapsing to ground, vacant hollow eyes, limbs weak and powerless" }
  ],
  // 愤怒反应
  anger: [
    { desc: "青筋暴起，咬牙切齿", prompt: "veins bulging on neck and forehead, teeth clenched grinding, nostrils flaring, face flushed red" },
    { desc: "怒目圆睁，手指颤抖", prompt: "glaring eyes wide with rage, trembling pointing finger, heavy rapid breathing" },
    { desc: "摔物发泄，面部扭曲", prompt: "smashing objects in rage, face contorted with anger, aggressive body language" },
    { desc: "冷笑威胁，眼神凌厉", prompt: "cold menacing smile, sharp piercing eyes, suppressed rage, intimidating stare" }
  ],
  // 悲伤反应
  sadness: [
    { desc: "无声落泪，肩膀颤抖", prompt: "silent tears streaming down, shoulders trembling, head bowed down in sorrow" },
    { desc: "崩溃大哭，蜷缩抱膝", prompt: "breaking down sobbing, curled up hugging knees, body shaking with grief" },
    { desc: "强忍泪水，嘴角下撇", prompt: "holding back tears, corners of mouth drooping, pained expression, red-rimmed eyes" },
    { desc: "绝望空洞，目光呆滞", prompt: "hollow desperate eyes, vacant stare into distance, soul-crushing despair" }
  ],
  // 喜悦反应
  joy: [
    { desc: "喜极而泣，双手颤抖", prompt: "crying tears of joy, hands trembling with excitement, radiant smile, glowing face" },
    { desc: "开怀大笑，眉眼弯弯", prompt: "laughing heartily, eyes crinkling with joy, carefree expression, genuine happiness" },
    { desc: "惊喜捂嘴，眼睛发亮", prompt: "surprised hand covering mouth, eyes sparkling bright, delighted expression" },
    { desc: "激动跳跃，挥舞手臂", prompt: "jumping with excitement, waving arms enthusiastically, euphoric celebration" }
  ],
  // 紧张/焦虑反应
  tension: [
    { desc: "咬唇搓手，坐立不安", prompt: "biting lip nervously, rubbing hands together, restless fidgeting, anxious expression" },
    { desc: "额头冒汗，眼神躲闪", prompt: "sweat on forehead, eyes darting around avoiding contact, nervous swallowing" },
    { desc: "深呼吸镇定，强装冷静", prompt: "taking deep breaths to calm down, forcing composure, barely concealed anxiety" },
    { desc: "手指敲击，目光紧盯", prompt: "fingers tapping impatiently, eyes fixed and intense, building tension" }
  ],
  // 爱恋反应
  love: [
    { desc: "含情脉脉，嘴角含笑", prompt: "gazing affectionately, gentle smile on lips, soft loving eyes, tender expression" },
    { desc: "脸红心跳，低头羞涩", prompt: "blushing cheeks, looking down shyly, fluttering eyelashes, bashful smile" },
    { desc: "深情凝视，伸手触碰", prompt: "deep emotional gaze, reaching out to touch, longing expression, romantic atmosphere" },
    { desc: "幸福满足，依偎靠近", prompt: "content satisfied smile, leaning in close, comfortable intimacy, warm glow" }
  ]
};

// 根据文本内容分析情绪类型
export function analyzeEmotion(text: string): keyof typeof reactionTemplates {
  const lowerText = text.toLowerCase();
  
  // 愤怒关键词
  if (/怒|恨|杀|死|混蛋|可恶|气|吼|咆哮|愤怒|怒视|咬牙切齿/.test(lowerText)) {
    return 'anger';
  }
  // 悲伤关键词
  if (/哭|泪|伤心|痛苦|绝望|悲|哀|痛|伤|难过|心碎/.test(lowerText)) {
    return 'sadness';
  }
  // 喜悦关键词
  if (/笑|喜|开心|高兴|快乐|幸福|激动|兴奋|欢呼|耶|棒/.test(lowerText)) {
    return 'joy';
  }
  // 紧张关键词
  if (/紧张|害怕|担心|焦虑|不安|恐惧|怕|慌|抖|冷汗/.test(lowerText)) {
    return 'tension';
  }
  // 爱恋关键词
  if (/爱|喜欢|心动|温柔|深情|暧昧|吻|抱|亲爱的/.test(lowerText)) {
    return 'love';
  }
  // 震惊关键词
  if (/惊|吓|呆|愣|什么|怎么可能|不可能|震惊|吓呆/.test(lowerText)) {
    return 'shock';
  }
  
  // 默认根据标点符号判断
  if (/[!！]{2,}/.test(lowerText)) return 'anger';
  if (/[?？]{2,}/.test(lowerText)) return 'shock';
  if (/~|～/.test(lowerText)) return 'joy';
  
  return 'shock'; // 默认震惊
}

// 获取随机反应模板
export function getRandomReaction(emotionType: keyof typeof reactionTemplates): { desc: string; prompt: string } {
  const templates = reactionTemplates[emotionType];
  const randomIndex = Math.floor(Math.random() * templates.length);
  return templates[randomIndex];
}

// 风格模板
export const styleTemplates: Record<string, string> = {
  xh: "golden fantasy style, mystical atmosphere, ethereal golden lighting, magical elements floating, xianxia aesthetic",
  xx: "immortal fantasy, misty mountains, ethereal clouds, celestial atmosphere, wuxia elegance",
  md: "dark metropolitan, neon-lit cyberpunk, moody atmosphere, urban grit",
  gw: "ancient martial arts, heroic blood, traditional Chinese aesthetic, intense action"
};

// 动势模板
export const motionTemplates: Record<string, string> = {
  ultra: "extreme dynamic motion, hair and clothing fully extended by momentum, freeze frame at peak action",
  high: "high momentum, visible motion energy, flowing garments",
  mid: "natural movement, realistic motion, grounded action"
};

// 特效模板
export const fxTemplates: Record<string, string> = {
  rich: "golden runes swirling, energy pillars erupting, magical circles forming, spectacular VFX",
  subtle: "gentle particle effects, soft glow, minimal magical elements",
  none: "no special effects, pure cinematography, realistic only"
};

// 生成完整提示词
export function generatePrompt(
  style: string,
  emotion: string,
  camera: string,
  motion: string,
  fx: string,
  customPrompt: string
): string {
  const styleDesc = styleTemplates[style] || styleTemplates.xh;
  const emotionDesc = emotionTemplates[emotion] || emotionTemplates.max;
  const motionDesc = motionTemplates[motion] || motionTemplates.ultra;
  const fxDesc = fxTemplates[fx] || fxTemplates.rich;
  
  return `${styleDesc}, ${emotionDesc}, ${motionDesc}, ${fxDesc}${customPrompt ? ', ' + customPrompt : ''}, hyper-realistic rendering, 8K ultra HD, RAW cinematic tone, theatrical quality, real physical lighting, no cartoon feel, Douyin vertical screen 9:16, masterpiece quality`;
}

// 根据剧本内容智能选择模板
export function selectTemplates(script: string, camera: string) {
  const templates = cameraTemplates[camera] || cameraTemplates.side;
  
  // 简单的关键词匹配
  const hasDialogue = script.includes('：') || script.includes('"') || script.includes('"');
  const hasAction = script.includes('（') || script.includes('）');
  const hasEmotion = /愤怒|悲伤|震惊|恐惧|狂喜/.test(script);
  
  // 根据内容选择合适的模板
  if (hasEmotion && templates.length > 1) {
    return templates[1]; // 通常第二个是情绪爆发模板
  }
  
  return templates[0];
}
