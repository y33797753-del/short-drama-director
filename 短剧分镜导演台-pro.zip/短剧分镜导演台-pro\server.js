import express from 'express';
import { GoogleGenAI } from '@google/genai';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

// 从环境变量获取 API Key（部署时设置）
const API_KEY = process.env.GEMINI_API_KEY || '';

if (!API_KEY) {
  console.warn('警告: 未设置 GEMINI_API_KEY 环境变量，AI 功能将不可用');
}

const ai = API_KEY ? new GoogleGenAI({ apiKey: API_KEY }) : null;

app.use(cors());
app.use(express.json({ limit: '50mb' }));

// 静态文件服务
app.use(express.static(path.join(__dirname, 'dist')));

// 健康检查
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    aiAvailable: !!ai,
    hasApiKey: !!API_KEY
  });
});

// 剧本分析 API
app.post('/api/analyze', async (req, res) => {
  if (!ai) {
    return res.status(503).json({ error: 'AI 服务未配置' });
  }

  try {
    const { script, charImages, sceneImages } = req.body;
    
    const parts = [{
      text: `作为专业的抖音爆款短剧导演，请深度解析以下剧本。
要求：
1. 提取核心冲突、人物性格、场景氛围和情绪转折点。
2. 梳理出剧本中的关键台词，并明确指出"这句台词是谁说的"，以及"说完后观众/镜头的反应应该切给谁"。
3. 如果我上传了场景或角色参考图，请结合参考图的特征，描述场景的具体细节和角色的外貌特征。
4. 保持简明扼要，具有实操指导意义。

剧本内容：
${script}`
    }];

    // 添加角色参考图
    if (charImages && charImages.length > 0) {
      charImages.forEach((img) => {
        const base64Data = img.data.split(',')[1];
        const mimeType = img.data.split(';')[0].split(':')[1];
        parts.push({ text: `[参考图：角色 - ${img.name}]` });
        parts.push({ inlineData: { data: base64Data, mimeType } });
      });
    }

    // 添加场景参考图
    if (sceneImages && sceneImages.length > 0) {
      sceneImages.forEach((img) => {
        const base64Data = img.data.split(',')[1];
        const mimeType = img.data.split(';')[0].split(':')[1];
        parts.push({ text: `[参考图：场景 - ${img.name}]` });
        parts.push({ inlineData: { data: base64Data, mimeType } });
      });
    }

    const response = await ai.models.generateContent({
      model: 'gemini-2.0-flash',
      contents: { parts },
      config: {
        systemInstruction: "你是一个专业的短剧剧本分析师。如果用户上传了参考图并自定义了名称，你必须仔细观察参考图中的场景和角色，并在解析中明确指出这些视觉特征与自定义名称的对应关系，以便后续分镜生成时使用。"
      }
    });

    res.json({ result: response.text });
  } catch (error) {
    console.error('分析失败:', error);
    res.status(500).json({ error: error.message });
  }
});

// 角色分析 API
app.post('/api/analyze-characters', async (req, res) => {
  if (!ai) {
    return res.status(503).json({ error: 'AI 服务未配置' });
  }

  try {
    const { fullScript } = req.body;
    
    const response = await ai.models.generateContent({
      model: 'gemini-2.0-flash',
      contents: `作为专业的短剧剧本分析师，请深度解析以下完整剧本中的所有角色。
要求：
1. 列出所有出场角色，并详细分析他们的性格特点、外貌特征（如果剧本有提及）、说话方式和习惯性肢体动作。
2. 分析角色之间的核心关系和情感纠葛。
3. 保持简明扼要，具有实操指导意义，以便后续生成分镜提示词时能准确把握每个角色的神态和动作。

完整剧本内容：
${fullScript}`,
      config: {
        systemInstruction: "你是一个专业的短剧剧本分析师。你的任务是提取角色的性格特征，为后续的分镜生成提供准确的人物画像。"
      }
    });

    res.json({ result: response.text });
  } catch (error) {
    console.error('角色分析失败:', error);
    res.status(500).json({ error: error.message });
  }
});

// 运镜分析 API
app.post('/api/analyze-camera', async (req, res) => {
  if (!ai) {
    return res.status(503).json({ error: 'AI 服务未配置' });
  }

  try {
    const { script } = req.body;
    
    const response = await ai.models.generateContent({
      model: 'gemini-2.0-flash',
      contents: `作为专业的短剧导演，请分析以下剧本片段，推荐最适合的运镜风格。
剧本内容：
${script}

请从以下选项中选择一个最合适的运镜风格：
- side: 侧面/斜侧优先（适合对话、情绪爆发）
- mix: 混合运镜（适合平缓过渡、日常）
- epic: 史诗大景（适合大场面、环境展示）
- intimate: 亲密特写（适合内心戏、微表情）
- fpv: 第一人称视角（适合代入感、主观视角）
- tracking: 动态跟拍（适合追逐、运动、行走）
- orbit: 环绕镜头（适合展现人物气场、对峙、高光时刻）

请直接返回对应的英文选项（如：side, mix, epic, intimate, fpv, tracking, orbit），不要返回任何其他内容。`,
      config: {
        systemInstruction: "你是一个专业的短剧导演。你的任务是根据剧本内容，推荐最合适的运镜风格。只返回选项的英文单词。"
      }
    });

    res.json({ result: response.text?.trim().toLowerCase() || 'side' });
  } catch (error) {
    console.error('运镜分析失败:', error);
    res.status(500).json({ error: error.message });
  }
});

// 生成分镜提示词 API（流式）
app.post('/api/generate', async (req, res) => {
  if (!ai) {
    return res.status(503).json({ error: 'AI 服务未配置' });
  }

  try {
    const { 
      script, 
      fullScript,
      characterAnalysis,
      charImages, 
      sceneImages,
      style,
      emotion,
      camera,
      pace,
      motion,
      fx,
      duration,
      totalDuration,
      markers,
      customPromptAdditions
    } = req.body;

    const styleMap = { 'xh': '金色玄幻', 'xx': '仙侠飘渺', 'md': '魔都暗黑', 'gw': '古武热血' };
    const emotionMap = { 'max': '极致爆发', 'hi': '高度外放', 'mid': '中度戏剧' };
    const cameraMap = { 'side': '侧面/斜侧优先', 'mix': '混合运镜', 'epic': '史诗大景', 'intimate': '亲密特写', 'fpv': '第一人称视角', 'tracking': '动态跟拍', 'orbit': '环绕镜头' };
    const paceMap = { 'flow': '流畅节奏', 'cut': '快切节奏', 'epic': '史诗升格' };
    const motionMap = { 'ultra': '极强动势', 'high': '高动势', 'mid': '自然动势' };
    const fxMap = { 'rich': '华丽丰富', 'subtle': '点缀微光', 'none': '无特效纯实拍' };

    const promptText = `
你是一位顶级的抖音述评短剧分镜大师。请严格按照以下剧本，将其按时间顺序拆解为连续的、不重复的多个分镜，并生成专供【即梦 Seedance 2.0】使用的超详细英文提示词（Prompt）。

【🔴 核心痛点与强制规则 - 违背视为失败】：
1. 🚫 彻底拒绝重复，必须推进剧情：你必须按剧本时间线顺延拆解！每一个分镜必须是剧情的下一步。绝对不能在多个分镜中重复相同的台词、动作或提示词！如果剧本有5句话，你必须把这5句话分配到不同的分镜中，绝不能让5个分镜都在演同一句话！
2. ⏱️ 严格时长控制：所有分镜的时长相加，总时长【必须严格控制在 ${totalDuration}秒 之间】！请在每个分镜明确标注时长，并确保总和达标。
3. 🗣️ 台词与多重反应切镜：每个分镜必须明确写出"当前台词是谁说的"，说话时的【肢体辅助动作】是什么。并且，每个分镜必须增加对【至少3个不同配角】的反应镜头描述，并详细说明他们的微表情和情绪变化。
4. 🖼️ 严格遵循参考图与自定义名称：
   - 场景：必须先分析上传的场景参考图，分镜提示词里关于场景的描述一定要延续上传的参考图，不要出现莫须有的场景描述！如果用户自定义了场景名称，请在提示词中体现该场景特征。
   - 角色：必须延续参考图的特征，绝对不得随意捏造人物长相、服装。画面中绝对不要出现多余的无关人物。如果用户自定义了角色名称，请务必将该名称与角色特征绑定，并在生成的英文提示词中体现！
5. ✨ 精准且宏大的特效（VFX）：严格按照剧本，不是每个镜头都有特效！只有当剧本明确需要特效（如施法、爆发、打斗）时才添加。有特效的镜头，描述一定要宏伟、好看、壮观（参考"仙逆施法特效"），例如："升腾的金色符文缠绕全身，爆发出耀眼的能量光柱，撕裂天空，形成巨大的金色漩涡"。确保特效描述与整体风格（金色、玄幻）一致。
6. 💡 创意运镜与构图：为每个生成的分镜，提供2-3个与当前选定运镜风格和构图手法相匹配的、更具创意的运镜和构图组合建议。
7. 🛑 附加全局提示词规则：用户提供的附加全局提示词必须且只能出现在【镜号标题处】，**绝对不要**将其放入最终生成的即梦 Seedance 2.0 英文提示词代码块中！

【🎬 即梦 Seedance 2.0 专属视觉与风格设定】：
- 🎭 人物性格与动作分析：在生成提示词前，请先深度分析剧本中每个人物的性格。根据他们的性格，为其设计符合身份的、不夸张但具有表现力的竖屏短剧肢体动作和说话方式。拒绝空洞的"浮夸表演"，必须具体到微表情和肢体细节！例如："咬牙切齿的愤怒 (gnashing teeth in extreme anger)"、"难以置信的震惊 (eyes wide open in unbelievable shock)"。肢体动作必须细化，如"猛地后退一步 (suddenly stepping back)"、"双手紧握成拳 (clenching fists tightly)"。让动作与台词、剧情完美咬合！
- 🎥 顶级分镜组合与运镜细节：优化镜头衔接，运用推拉摇移跟等复杂运镜（e.g., rapid zoom in, slow panning, dynamic tracking shot）。多使用侧面拍摄（Side-angle shots）、低角度仰拍（Low-angle shot for dominance）、高角度俯拍（High-angle shot for vulnerability）来增强视觉冲击力。
- 💡 殿堂级光影表现：光影实时投射动态阴影 (real-time dynamic shadows and lighting)，强调体积光（Volumetric lighting）、丁达尔效应（Tyndall effect）、边缘轮廓光（Rim lighting）以及高反差的戏剧性光影（Dramatic high-contrast lighting）。
- 基础画质：Hyper-realistic rendering, 8K ultra HD, RAW cinematic tone, theatrical quality, real physical lighting, no cartoon feel, Douyin vertical screen 9:16. 超写实风格，玄幻风格感觉，画面极具视觉冲击力，构图美观，富有创意，给你赋予想象力的权限画面一定要真实，直给的画面不要压抑，大师级别的运镜。
- 动态与细节：场景材质纹理真实 (realistic textures and materials), 场景所有元素动态运动如布料飘动、发丝飞舞 (dynamic movement of all scene elements, e.g., cloth fluttering in the wind, hair blowing). 夸张的面部表情溢出屏幕的情绪。
- 排除项：画面中绝对不要出现任何字幕（No text, no subtitles）和BGM符号。不要出现多余的人物。

【⚙️ 当前用户动态参数配置】（必须严格根据这些参数调整你的分镜设计和英文提示词，不同的参数配置必须生成截然不同的提示词）：
1. 画面风格：${styleMap[style] || style}
2. 情绪张力：${emotionMap[emotion] || emotion}
3. 运镜风格：${cameraMap[camera] || camera}
4. 剪辑节奏：${paceMap[pace] || pace}
5. 人物动势：${motionMap[motion] || motion}
6. 特效密度：${fxMap[fx] || fx}
7. 单镜时长：${duration === '0' ? '智能动态' : duration + '秒'}
8. 分镜总时长：${totalDuration}秒
9. 剪辑标记：${markers === 'on' ? '开启' : '关闭'}
10. 附加全局提示词：${customPromptAdditions}

【📜 剧本内容】：
${script}

${characterAnalysis ? `【🎭 角色性格深度解析（作为生成提示词的参考）】：\n${characterAnalysis}\n` : ''}

【📝 输出格式要求】（请严格使用以下 Markdown 格式输出）：

### 🎬 镜号：[Shot 1] | ⏱ 时长：[X]秒

**【📋 全局提示词配置】**：${customPromptAdditions || '无'}

---

**📖 对应原剧本**：[摘录当前分镜对应的原剧本句子，证明你没有重复]

**🗣️ 台词与多重反应**：[例如：玄烬说话（歇斯底里的悲伤，眼泪甩出：爹爹的血脉已经断绝了，世间无人能治。） -> 反应镜头先切给震惊的林动，再切给冷笑的黑衣人，最后切给恐惧的村民，详细描述这至少3个配角的微表情和情绪变化]

**【制作规格】**：电影胶片颗粒质感，高动态范围HDR色调，9:16竖屏，短剧爆款风格，情绪冲击力拉满

**【运镜·[运镜手法]】**：[详细描述运镜，例如：摄影机在斜后侧45度强逆光位，人物整体呈轮廓光剪影，缓缓向侧前方推进旋转，从剪影过渡到半侧清晰近景，服饰边缘形成耀眼光边]

**【景别·[景别类型]】**：[详细描述景别，例如：medium shot，人物膝盖以上入画，清晰展现上身动作手势，表情可见动作可辨]

**【流畅构图·[构图手法]】**：[详细描述构图，例如：人物背面或侧面剪影置于竖屏对角线，大片留黑的负空间衬托冲击力]

**💡 创意运镜与构图建议**：[提供2-3个与当前选定运镜风格和构图手法相匹配的、更具创意的运镜和构图组合建议]

**【场景·写实呈现】**：依据剧本："[当前台词/动作]"；[结合参考图详细描述场景，例如：场景材质纹理真实，光影实时投射动态阴影；布料在气流中猎猎飘扬，光影随特效实时变化；超写实渲染，8K超高清，RAW电影色调，院线质感，真实物理光照，无卡通感，抖音竖屏9:16]

**【人物动势】**：[详细描述动势，例如：人物正处于运动弧线顶点，服饰和发丝都随动势展开，力量感与仪式感并存]

**【环境叙事·动态沉浸】**：依据剧本："[当前台词/动作]"；[详细描述环境，例如：从斜侧45度角呈现，人物轮廓在光线中勾勒出强烈动势，光影动态投射]

**【光色质感】**：[详细描述光色，例如：丁达尔散射：光束穿过环境形成散射，空气中微粒在光柱中漂浮运动，神圣感满溢；整体色调：高对比度，华美壮观，金色主调]

**【剪辑·流畅】**：入点：[例如：前镜余势收尾时]；出点：[例如：本镜情绪达到饱和时]；衔接自然，动作连贯，情绪递进

**🪄 即梦 Seedance 2.0 英文提示词**：
\`\`\`text
[此处填写极其详细的英文提示词，必须包含上述所有分析的视觉词汇、极致面部表情、细化肢体动作、复杂运镜、殿堂级光影、动态元素等。注意：绝对不要包含"附加全局提示词"的内容，不少于 80 个英文单词]
\`\`\`

---

（请以此类推，直到剧本结束，确保总时长在 ${totalDuration}秒 之间，绝对不许重复同一个镜头！）
`;

    const parts = [{ text: promptText }];

    // 添加角色参考图
    if (charImages && charImages.length > 0) {
      charImages.forEach((img) => {
        const base64Data = img.data.split(',')[1];
        const mimeType = img.data.split(';')[0].split(':')[1];
        parts.push({ text: `[参考图：角色 - ${img.name}]` });
        parts.push({ inlineData: { data: base64Data, mimeType } });
      });
    }

    // 添加场景参考图
    if (sceneImages && sceneImages.length > 0) {
      sceneImages.forEach((img) => {
        const base64Data = img.data.split(',')[1];
        const mimeType = img.data.split(';')[0].split(':')[1];
        parts.push({ text: `[参考图：场景 - ${img.name}]` });
        parts.push({ inlineData: { data: base64Data, mimeType } });
      });
    }

    // 设置 SSE 响应头
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');

    const responseStream = await ai.models.generateContentStream({
      model: 'gemini-2.0-flash',
      contents: { parts },
      config: {
        systemInstruction: "你是一个严格执行指令的顶级短剧分镜导演。你的首要任务是【绝对不重复】：必须严格按照剧本的时间线推进，每个分镜必须对应剧本的下一句话或下一个动作，绝不能在多个分镜中重复同一句台词！其次，你必须【严格应用用户的动态参数配置】（如运镜风格、画面风格、特效密度），确保不同的配置生成截然不同的英文提示词。最后，你必须【仔细观察参考图和用户自定义的名称】，在提示词中完美还原参考图的场景和角色特征，并将用户自定义的名称与特征绑定。请在每个分镜中多加入一些反应镜头（Reaction Shots）。"
      }
    });

    for await (const chunk of responseStream) {
      if (chunk.text) {
        res.write(`data: ${JSON.stringify({ text: chunk.text })}\n\n`);
      }
    }

    res.write('data: [DONE]\n\n');
    res.end();
  } catch (error) {
    console.error('生成失败:', error);
    res.status(500).json({ error: error.message });
  }
});

// 所有其他路由返回 index.html（支持前端路由）
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`服务器运行在端口 ${PORT}`);
  console.log(`AI 服务状态: ${ai ? '已配置' : '未配置'}`);
});
