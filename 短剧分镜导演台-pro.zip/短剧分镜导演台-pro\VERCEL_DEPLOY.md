# Vercel 一键部署指南

## 方案 A：使用 Vercel CLI（推荐）

### 1. 安装 Vercel CLI
```bash
npm i -g vercel
```

### 2. 登录 Vercel
```bash
vercel login
```
按提示完成登录

### 3. 部署项目
```bash
cd 短剧分镜导演台-pro
vercel --prod
```

### 4. 设置环境变量
部署完成后，在 Vercel Dashboard 中：
1. 进入项目设置
2. 点击 "Environment Variables"
3. 添加变量：
   - **Name**: `GEMINI_API_KEY`
   - **Value**: `AIzaSyBG-yn_OHUywnJy7x_LgT_XBziHjX6NyLY`

### 5. 重新部署
```bash
vercel --prod
```

---

## 方案 B：使用 Vercel Web 界面

### 1. 准备代码
将 `短剧分镜导演台-pro` 文件夹压缩为 zip 文件

### 2. 创建 GitHub 仓库
1. 访问 https://github.com/new
2. 创建新仓库（如 `short-drama-director`）
3. 上传代码到仓库

### 3. 连接 Vercel
1. 访问 https://vercel.com/new
2. 点击 "Import Git Repository"
3. 选择你的 GitHub 仓库
4. 点击 "Deploy"

### 4. 设置环境变量
部署完成后：
1. 进入 Vercel Dashboard
2. 选择你的项目
3. 点击 "Settings" → "Environment Variables"
4. 添加：
   - **Name**: `GEMINI_API_KEY`
   - **Value**: `AIzaSyBG-yn_OHUywnJy7x_LgT_XBziHjX6NyLY`

### 5. 重新部署
在 Vercel Dashboard 中点击 "Redeploy"

---

## 部署后访问

部署完成后，你会获得类似以下的链接：
- `https://short-drama-director.vercel.app`

这个链接：
- ✅ 无需密码
- ✅ 可以分享给好友
- ✅ 使用服务器 AI（配置了 API Key）

---

## 更新代码

如果后续需要更新：

**方案 A（CLI）**:
```bash
vercel --prod
```

**方案 B（GitHub）**:
推送代码到 GitHub，Vercel 会自动重新部署
