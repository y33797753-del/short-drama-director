// Vercel Serverless Function - 健康检查
export default function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  
  const API_KEY = process.env.GEMINI_API_KEY;
  
  res.json({
    status: 'ok',
    aiAvailable: !!API_KEY,
    hasApiKey: !!API_KEY,
    timestamp: new Date().toISOString()
  });
}
