# Render 部署指南

## 快速部署步骤

### 1. 准备工作
- 访问 https://dashboard.render.com
- 登录你的账号（可以用 GitHub 账号直接登录）

### 2. 创建 Web Service
1. 点击 "New +" 按钮
2. 选择 "Web Service"
3. 选择 "Upload your code" 选项

### 3. 上传代码
1. 将项目文件夹压缩为 zip 文件
2. 在 Render 上传界面选择该 zip 文件

### 4. 配置服务
- **Name**: `short-drama-director`（或你喜欢的名字）
- **Runtime**: Node
- **Build Command**: `npm install && npm run build`
- **Start Command**: `npm start`

### 5. 添加环境变量
在 "Environment" 标签页添加：
- **Key**: `GEMINI_API_KEY`
- **Value**: `AIzaSyBG-yn_OHUywnJy7x_LgT_XBziHjX6NyLY`

### 6. 创建服务
点击 "Create Web Service"

### 7. 等待部署完成
- 构建过程大约需要 2-3 分钟
- 完成后会显示 "Live" 状态
- 获得类似 `https://short-drama-director.onrender.com` 的链接

## 注意事项

1. **免费额度**: Render 免费版有 15 分钟无活动休眠限制，首次访问可能需要等待唤醒
2. **API 额度**: 每天 1500 次请求（Google 免费 tier）
3. **自定义域名**: 可以在 Render 设置中添加自己的域名

## 更新部署

如果需要更新代码：
1. 在 Render Dashboard 找到你的服务
2. 点击 "Manual Deploy" → "Deploy latest commit"
3. 或者开启 Auto-Deploy（自动部署）
