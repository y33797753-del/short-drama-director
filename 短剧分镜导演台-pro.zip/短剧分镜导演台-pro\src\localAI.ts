// 本地 AI 模型 - 使用 Transformers.js
// 在浏览器中运行，无需服务器

import { pipeline, env } from '@xenova/transformers';

// 配置环境
env.allowLocalModels = false;
env.useBrowserCache = true;

// 尝试使用国内镜像，如果失败会回退到官方源
const useMirror = true;
if (useMirror) {
  try {
    // @ts-ignore
    env.remoteHost = 'https://hf-mirror.com';
    // @ts-ignore
    env.remotePathTemplate = '{model}/resolve/main/{file}';
  } catch (e) {
    console.warn('镜像配置失败，使用官方源');
  }
}

let textGenerationPipeline: any = null;
let modelLoading = false;
let modelLoaded = false;
let loadError: string | null = null;

// 模型配置 - 使用千问开源模型
const MODEL_NAME = 'Xenova/Qwen2.5-0.5B-Instruct'; // 千问 0.5B 模型，约 300MB
const FALLBACK_MODEL = 'Xenova/tinyllama-v1.1'; // 备用模型，约 100MB

// 初始化本地 AI
export async function initLocalAI(onProgress?: (msg: string) => void): Promise<boolean> {
  if (modelLoaded) return true;
  if (modelLoading) {
    while (modelLoading) {
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    return modelLoaded;
  }

  modelLoading = true;
  loadError = null;
  
  try {
    console.log('正在加载本地 AI 模型...');
    if (onProgress) onProgress('正在下载千问模型(约300MB)，请耐心等待...');
    
    // 添加超时处理
    const timeoutPromise = new Promise((_, reject) => {
      setTimeout(() => reject(new Error('下载超时，请检查网络连接')), 300000); // 5分钟超时
    });
    
    const loadPromise = pipeline(
      'text-generation',
      MODEL_NAME,
      {
        progress_callback: (progress: any) => {
          if (progress && onProgress && progress.total) {
            const percent = Math.round((progress.loaded / progress.total) * 100);
            onProgress(`千问模型: ${percent}% (${(progress.loaded / 1024 / 1024).toFixed(1)}MB / ${(progress.total / 1024 / 1024).toFixed(1)}MB)`);
          } else if (progress && onProgress) {
            onProgress(`已下载: ${(progress.loaded / 1024 / 1024).toFixed(1)}MB`);
          }
        }
      }
    );
    
    textGenerationPipeline = await Promise.race([loadPromise, timeoutPromise]);
    
    modelLoaded = true;
    console.log('本地 AI 模型加载完成！');
    if (onProgress) onProgress('千问模型加载完成！');
    return true;
  } catch (error: any) {
    console.error('千问模型加载失败，尝试备用模型:', error);
    if (onProgress) onProgress('千问模型下载失败，尝试备用模型...');
    
    // 尝试备用模型
    try {
      const fallbackTimeoutPromise = new Promise((_, reject) => {
        setTimeout(() => reject(new Error('备用模型下载超时')), 180000); // 3分钟超时
      });
      
      const fallbackPromise = pipeline(
        'text-generation',
        FALLBACK_MODEL,
        {
          progress_callback: (progress: any) => {
            if (progress && onProgress && progress.total) {
              const percent = Math.round((progress.loaded / progress.total) * 100);
              onProgress(`备用模型: ${percent}% (${(progress.loaded / 1024 / 1024).toFixed(1)}MB)`);
            }
          }
        }
      );
      
      textGenerationPipeline = await Promise.race([fallbackPromise, fallbackTimeoutPromise]);
      modelLoaded = true;
      if (onProgress) onProgress('备用模型加载完成！(英文模型，中文效果可能不佳)');
      return true;
    } catch (fallbackError: any) {
      loadError = '所有模型加载失败: ' + (error.message || '网络连接问题');
      modelLoaded = false;
      return false;
    }
  } finally {
    modelLoading = false;
  }
}

// 获取加载错误信息
export function getLoadError(): string | null {
  return loadError;
}

// 检查模型是否已加载
export function isModelLoaded(): boolean {
  return modelLoaded;
}

// 生成分镜提示词
export async function generateShotsWithLocalAI(
  script: string,
  style: string,
  emotion: string,
  camera: string,
  motion: string,
  fx: string,
  customPrompt: string,
  onProgress?: (text: string) => void
): Promise<string> {
  if (!modelLoaded || !textGenerationPipeline) {
    throw new Error('本地 AI 模型未加载，请先调用 initLocalAI()');
  }

  const styleMap: Record<string, string> = { 
    'xh': '金色玄幻', 
    'xx': '仙侠飘渺', 
    'md': '魔都暗黑', 
    'gw': '古武热血' 
  };
  const emotionMap: Record<string, string> = { 
    'max': '极致爆发', 
    'hi': '高度外放', 
    'mid': '中度戏剧' 
  };
  const cameraMap: Record<string, string> = { 
    'side': '侧面/斜侧优先', 
    'mix': '混合运镜', 
    'epic': '史诗大景', 
    'intimate': '亲密特写', 
    'fpv': '第一人称视角', 
    'tracking': '动态跟拍', 
    'orbit': '环绕镜头' 
  };

  const prompt = `你是一位专业的短剧分镜导演。请将以下剧本拆解为分镜，并生成详细的拍摄提示词。

【剧本内容】：
${script}

【拍摄参数】：
- 画面风格：${styleMap[style] || style}
- 情绪张力：${emotionMap[emotion] || emotion}
- 运镜风格：${cameraMap[camera] || camera}
- 附加提示词：${customPrompt || '无'}

请按以下格式输出每个分镜：

### 🎬 镜号：[Shot X] | ⏱ 时长：[X]秒
**📖 对应原剧本**：[剧本原文]
**🗣️ 台词与反应**：[描述]
**【运镜】**：[详细运镜描述]
**【景别】**：[景别类型]
**【构图】**：[构图描述]
**【光色】**：[光影描述]
**🪄 英文提示词**：
\`\`\`text
[英文提示词，包含运镜、光影、情绪、风格等关键词，适合即梦 Seedance 2.0]
\`\`\`

请生成详细的分镜提示词：
`;

  try {
    const result = await textGenerationPipeline(prompt, {
      max_new_tokens: 2048,
      temperature: 0.7,
      do_sample: true,
      top_k: 50,
      top_p: 0.9,
      repetition_penalty: 1.1,
      callback_function: (x: any) => {
        if (onProgress && x[0]?.generated_text) {
          onProgress(x[0].generated_text);
        }
      }
    });

    return result[0]?.generated_text || '生成失败';
  } catch (error) {
    console.error('生成失败:', error);
    throw error;
  }
}

// 简单的剧本分析
export async function analyzeScriptWithLocalAI(script: string): Promise<string> {
  if (!modelLoaded || !textGenerationPipeline) {
    throw new Error('本地 AI 模型未加载');
  }

  const prompt = `分析以下短剧剧本，提取核心冲突、人物性格和场景氛围：

${script}

请简明扼要地分析：
`;

  try {
    const result = await textGenerationPipeline(prompt, {
      max_new_tokens: 512,
      temperature: 0.5,
    });

    return result[0]?.generated_text || '分析失败';
  } catch (error) {
    console.error('分析失败:', error);
    throw error;
  }
}

// 获取模型状态
export function getModelStatus(): 'loading' | 'loaded' | 'error' | 'not_loaded' {
  if (modelLoading) return 'loading';
  if (modelLoaded) return 'loaded';
  return 'not_loaded';
}
